local packs = {}
packs['automation-science-pack']='automation-science-pack'
packs['logistic-science-pack']='logistic-science-pack'
packs['military-science-pack']='military-science-pack'
packs['chemical-science-pack']='chemical-science-pack'
packs['production-science-pack']='production-science-pack'
packs['utility-science-pack']='utility-science-pack'
packs['space-science-pack']='space-science-pack'

if mods.boblogistics then
    packs['advanced-logistic-science-pack'] = 'advanced-logistic-science-pack'
end

if mods.bobtech then
    if settings.startup["bobmods-tech-colorupdate"].value then
	packs['automation-science-pack']='utility-science-pack'
        packs['logistic-science-pack']='automation-science-pack'
        packs['utility-science-pack']='logistic-science-pack'
    end
end            

for key,value in pairs(packs) do
    local science = data.raw['tool'][key]
    science.icon = '__BetterFlasks__/graphics/icons/' .. value .. '.png'
    science.icon_size = 64
    science.icon_mipmaps = 4
end