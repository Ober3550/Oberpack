if not bobmods then bobmods = {} end
if not bobmods.equipment then bobmods.equipment = {} end

require("prototypes.item.equipment")
require("prototypes.recipe.equipment")
require("prototypes.technology.equipment")
require("prototypes.equipment.equipment")
require("prototypes.beams")

require("prototypes.personal-roboport")
