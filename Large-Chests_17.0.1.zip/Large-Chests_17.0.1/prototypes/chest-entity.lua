--[[
      1x1, 2x2, 3x3
Wood  16 , 40 , 80
Iron  32 , 80 , 160
Steel 48 , 120, 240

Vanilla Resist
Wood  100                        1 sec mine
Iron  200 + 80% fire, 30% impact, 1 sec mine
Steel 350 + 90% fire, 60% impact, 1 sec mine.

Logistic 350 + 90% fire, 60% impact,   .2 hardness, .5 mining time.... Don't care. Treat as steel anyway.

Logistics 350 + 90% fire, 60% impact, 1 sec mine.

Wood   100
Iron   200 +  80% fire, 30% impact, 1 + 20% phys & exp & acid
Steel  350 +  90% fire, 60% impact, 2 + 40% phys & exp & acid

Wood2  200 +  20% fire, 10% impact, 1 + 10% phys & exp & acid
Iron2  400 +  85% fire, 40% impact, 2 + 30% phys & exp & acid
Steel2 700 +  95% fire, 70% impact, 3 + 50% phys & exp & acid

Wood3  200 +  40% fire, 20% impact, 2 + 20% phys & exp & acid
Iron3  400 +  90% fire, 50% impact, 3 + 40% phys & exp & acid
Steel3 700 + 100% fire, 80% impact, 4 + 60% phys & exp & acid


]]--


require("prototypes.chest-functions")

data:extend(
{
  {
    type = "container",
    name = "wooden-chest-medium",
    icon = "__Large-Chests__/graphics/icons/wooden-chest-plus.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "wooden-chest-medium"},
    max_health = 200,
    corpse = "medium-remnants",
    resistances = chest_resist["wood2x2"],
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
	fast_replaceable_group =  "container-medium",
    inventory_size = 40,
    open_sound = { filename = "__base__/sound/wooden-chest-open.ogg" },
    close_sound = { filename = "__base__/sound/wooden-chest-close.ogg" },
    vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/wooden-chest-medium.png",
      priority = "extra-high",
      width = 92,
      height = 66,
      shift = {0.4, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest2x2"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest2x2"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  {
    type = "container",
    name = "iron-chest-medium",
    icon = "__Large-Chests__/graphics/icons/iron-chest-plus.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "iron-chest-medium"},
    max_health = 400,
    corpse = "medium-remnants",
    resistances = chest_resist["iron2x2"],
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    fast_replaceable_group = "container-medium",
    inventory_size = 80,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/iron-chest-medium.png",
      priority = "extra-high",
      width = 96,
      height = 68,
      shift = {0.4, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest2x2"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest2x2"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  {
    type = "container",
    name = "steel-chest-medium",
    icon = "__Large-Chests__/graphics/icons/steel-chest-plus.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "steel-chest-medium"},
    max_health = 700,
    corpse = "medium-remnants",
    resistances = chest_resist["steel2x2"],
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    fast_replaceable_group = "container-medium",
    inventory_size = 120,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/steel-chest-medium.png",
      priority = "extra-high",
      width = 96,
      height = 68,
      shift = {0.4, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest2x2"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest2x2"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  {
    type = "container",
    name = "wooden-chest-big",
    icon = "__Large-Chests__/graphics/icons/wooden-chest-plus2.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "wooden-chest-big"},
    max_health = 400,
    corpse = "big-remnants",
    resistances = chest_resist["wood3x3"],
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
	fast_replaceable_group =  "container-big",
    inventory_size = 80,
    open_sound = { filename = "__base__/sound/wooden-chest-open.ogg" },
    close_sound = { filename = "__base__/sound/wooden-chest-close.ogg" },
    vehicle_impact_sound =  { filename = "__base__/sound/car-wood-impact.ogg", volume = 1.0 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/wooden-chest-big.png",
      priority = "extra-high",
      width = 138,
      height = 99,
      shift = {0.8, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest3x3"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest3x3"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  {
    type = "container",
    name = "iron-chest-big",
    icon = "__Large-Chests__/graphics/icons/iron-chest-plus2.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "iron-chest-big"},
    max_health = 800,
    corpse = "big-remnants",
    resistances = chest_resist["iron3x3"],
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    fast_replaceable_group = "container-big",
    inventory_size = 160,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/iron-chest-big.png",
      priority = "extra-high",
      width = 144,
      height = 102,
      shift = {0.8, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest3x3"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest3x3"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
  {
    type = "container",
    name = "steel-chest-big",
    icon = "__Large-Chests__/graphics/icons/steel-chest-plus2.png",
	icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 1, result = "steel-chest-big"},
    max_health = 1400,
    corpse = "big-remnants",
    resistances = chest_resist["steel3x3"],
    collision_box = {{-1.2, -1.2}, {1.2, 1.2}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    fast_replaceable_group = "container-big",
    inventory_size = 240,
    open_sound = { filename = "__base__/sound/metallic-chest-open.ogg", volume=0.65 },
    close_sound = { filename = "__base__/sound/metallic-chest-close.ogg", volume = 0.7 },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    picture =
    {
      filename = "__Large-Chests__/graphics/entities/steel-chest-big.png",
      priority = "extra-high",
      width = 144,
      height = 102,
      shift = {0.8, 0}
    },
    circuit_wire_connection_point = circuit_connector_definitions["chest3x3"].points,
    circuit_connector_sprites = circuit_connector_definitions["chest3x3"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
  },
}
)

data.raw["container"]["iron-chest"].resistances =
chest_resist["iron1x1"]
data.raw["container"]["steel-chest"].resistances  =
chest_resist["steel1x1"]
