--[[

      1x1, 2x2, 3x3
Wood  16 , 40 , 80
Iron  32 , 80 , 160
Steel 48 , 120, 240

Vanilla Resist
Wood  100                        1 sec mine
Iron  200 + 80% fire, 30% impact, 1 sec mine
Steel 350 + 90% fire, 60% impact, 1 sec mine.

Logistic 350 + 90% fire, 60% impact,   .2 hardness, .5 mining time.... Don't care. Treat as steel anyway.

Logistics 350 + 90% fire, 60% impact, 1 sec mine.

Wood   100
Iron   200 +  80% fire, 30% impact, 1 + 20% phys & exp & acid
Steel  350 +  90% fire, 60% impact, 2 + 40% phys & exp & acid

Wood2  200 +  20% fire, 10% impact, 1 + 10% phys & exp & acid
Iron2  400 +  85% fire, 40% impact, 2 + 30% phys & exp & acid
Steel2 700 +  95% fire, 70% impact, 3 + 50% phys & exp & acid

Wood3  200 +  40% fire, 20% impact, 2 + 20% phys & exp & acid
Iron3  400 +  90% fire, 50% impact, 3 + 40% phys & exp & acid
Steel3 700 + 100% fire, 80% impact, 4 + 60% phys & exp & acid







]]--
chest_resist = {};

chest_resist["wood1x1"] = 
{
  {
	type = "fire",
	percent = 0
  },
  {
	type = "impact",
	percent = 0
  },
  {
	type = "physical",
	percent = 0,
	decrease = 0
  },
  {
	type = "explosion",
	percent = 0,
	decrease = 0
  },
  {
	type = "acid",
	percent = 0,
	decrease = 0
  }
}

chest_resist["wood2x2"] = 
{
  {
	type = "fire",
	percent = 20
  },
  {
	type = "impact",
	percent = 10
  },
  {
	type = "physical",
	percent = 10,
	decrease = 1
  },
  {
	type = "explosion",
	percent = 10,
	decrease = 1
  },
  {
	type = "acid",
	percent = 10,
	decrease = 1
  }
}
chest_resist["wood3x3"] = 
{
  {
	type = "fire",
	percent = 40
  },
  {
	type = "impact",
	percent = 20
  },
  {
	type = "physical",
	percent = 20,
	decrease = 2
  },
  {
	type = "explosion",
	percent = 20,
	decrease = 2
  },
  {
	type = "acid",
	percent = 20,
	decrease = 2
  }
}

chest_resist["iron1x1"] = 
{
  {
	type = "fire",
	percent = 80
  },
  {
	type = "impact",
	percent = 30
  },
  {
	type = "physical",
	percent = 20,
	decrease = 1
  },
  {
	type = "explosion",
	percent = 20,
	decrease = 1
  },
  {
	type = "acid",
	percent = 20,
	decrease = 1
  }
}

chest_resist["iron2x2"] = 
{
  {
	type = "fire",
	percent = 85
  },
  {
	type = "impact",
	percent = 40
  },
  {
	type = "physical",
	percent = 30,
	decrease = 2
  },
  {
	type = "explosion",
	percent = 30,
	decrease = 2
  },
  {
	type = "acid",
	percent = 30,
	decrease = 2
  }
}
chest_resist["iron3x3"] = 
{
  {
	type = "fire",
	percent = 90
  },
  {
	type = "impact",
	percent = 50
  },
  {
	type = "physical",
	percent = 40,
	decrease = 3
  },
  {
	type = "explosion",
	percent = 40,
	decrease = 3
  },
  {
	type = "acid",
	percent = 40,
	decrease = 3
  }
}

chest_resist["steel1x1"] = 
{
  {
	type = "fire",
	percent = 90
  },
  {
	type = "impact",
	percent = 60
  },
  {
	type = "physical",
	percent = 40,
	decrease = 2
  },
  {
	type = "explosion",
	percent = 40,
	decrease = 2
  },
  {
	type = "acid",
	percent = 40,
	decrease = 2
  }
}

chest_resist["steel2x2"] = 
{
  {
	type = "fire",
	percent = 95
  },
  {
	type = "impact",
	percent = 70
  },
  {
	type = "physical",
	percent = 40,
	decrease = 3
  },
  {
	type = "explosion",
	percent = 40,
	decrease = 3
  },
  {
	type = "acid",
	percent = 40,
	decrease = 3
  }
}
chest_resist["steel3x3"] = 
{
  {
	type = "fire",
	percent = 100
  },
  {
	type = "impact",
	percent = 80
  },
  {
	type = "physical",
	percent = 50,
	decrease = 4
  },
  {
	type = "explosion",
	percent = 50,
	decrease = 4
  },
  {
	type = "acid",
	percent = 50,
	decrease = 4
  }
}
