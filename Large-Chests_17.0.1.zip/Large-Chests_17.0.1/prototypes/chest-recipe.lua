local vertical = settings.startup["large-chest-vertical"].value
local horizontal = settings.startup["large-chest-horizontal"].value
local woodRequired = settings.startup["large-chest-wood"].value

local function SetIngredients(recipe, wood, iron, steel, smallChest, largeChest)
    local tablez = {}
    if (wood) then
        table.insert(tablez, {"wood",wood})
    end
    if (iron) then
        table.insert(tablez, {"iron-plate",iron})
    end
    if (steel) then
        table.insert(tablez, {"steel-plate",steel})
    end
    if (smallChest and vertical) then
        table.insert(tablez, {smallChest,2})
    end
    if (largeChest and horizontal and (woodRequired or not string.find(largeChest,"wood"))) then
        table.insert(tablez, {largeChest,1})
    end
    
    data.raw["recipe"][recipe].ingredients = tablez
    
    
end



data:extend(
{
  {
    type = "recipe",
    name = "wooden-chest-medium",
    enabled = true,
    ingredients = 
    {
        --{"wood", 8},
        --{"iron-plate", 8}
    },
    result = "wooden-chest-medium"
  },
  {
    type = "recipe",
    name = "iron-chest-medium",
    enabled = false,
    ingredients = 
    {
        --{"wooden-chest-medium", 1},
        --{"iron-plate", 16}, -- 24
        --{"steel-plate", 8}
    },
    result = "iron-chest-medium"
  },
  {
    type = "recipe",
    name = "steel-chest-medium",
    enabled = false,
    ingredients = 
    {
        --{"iron-chest-medium", 1},
        --{"steel-plate", 32} -- 24
    },
    result = "steel-chest-medium"
  },
  {
    type = "recipe",
    name = "wooden-chest-big",
    enabled = false,
    ingredients = 
    {
        --{"wood", 16},
        --{"iron-plate", 16}
    },
    result = "wooden-chest-big"
  },
  {
    type = "recipe",
    name = "iron-chest-big",
    enabled = false,
    ingredients = 
    {
        --{"wooden-chest-big", 1},
        --{"iron-plate", 32},
        --{"steel-plate", 16} -- 48
    },
    result = "iron-chest-big"
  },
  {
    type = "recipe",
    name = "steel-chest-big",
    enabled = false,
    ingredients = 
    {
        --{"iron-chest-big", 1},
        --{"steel-plate", 64} -- 48
    },
    result = "steel-chest-big"
  },
}
)
    
SetIngredients("wooden-chest-medium",    8,  16, nil, "wooden-chest",            nil)
SetIngredients("iron-chest-medium"  ,  nil,  16,  16, "iron-chest"  , "wooden-chest-medium")
SetIngredients("steel-chest-medium" ,  nil, nil,  16, "steel-chest" , "iron-chest-medium")


SetIngredients("wooden-chest-big"   ,   16,  32, nil, "wooden-chest-medium",            nil)
SetIngredients("iron-chest-big"     ,  nil,  32,  32, "iron-chest-medium"  , "wooden-chest-big")
SetIngredients("steel-chest-big"    ,  nil, nil,  32, "steel-chest-medium" , "iron-chest-big")


