function modSetting(modsetting) return settings.startup[modsetting] end
function technology(technology) return data.raw.technology[technology] end

