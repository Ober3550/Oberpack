if modSetting("wit-research-disablemodresearch").value ~= "Disabled" then

    if data.raw.technology["bob-artillery-speed-5"] then
        data:extend({
            {
                type = "technology",
                name = "bob-artillery-speed-6",
                icon = "__base__/graphics/technology/cannon-speed.png",
                icon_size = 64,
                effects =
                {
                    {
                        type = "gun-speed",
                        ammo_category = "artillery-shell",
                        modifier = 1
                    }
                },
                prerequisites = {"bob-artillery-speed-5"},
                unit =
                {
                    count_formula = "(L-5)*1000",
                    ingredients =
                    {
                        {"military-science-pack", 1},
                        {"science-pack-1", 1},
                        {"science-pack-2", 1},
                        {"science-pack-3", 1},
                        {"high-tech-science-pack", 1},
                        {"space-science-pack", 1}
                    },
                    time = 60
                },
                max_level = "infinite",
                upgrade = "true",
                order = "e-o-l"
            }
        })

    end

    if data.raw.technology["bob-laser-rifle-speed-6"] then

        data:extend({

            {
                type = "technology",
                name = "bob-laser-rifle-speed-7",
                icon = "__bobwarfare__/graphics/icons/technology/laser-rifle.png",
                icon_size = 64,
                effects =
                {
                    {
                        type = "gun-speed",
                        ammo_category = "laser-rifle",
                        modifier = 0.3
                    }
                },
                prerequisites = {"bob-laser-rifle-speed-6"},
                unit =
                {
                    count_formula = "(L-6)*1000",
                    ingredients =
                    {
                        {"science-pack-1", 1},
                        {"science-pack-2", 1},
                        {"science-pack-3", 1},
                        {"military-science-pack", 1},
                        {"high-tech-science-pack", 1},
                        {"space-science-pack", 1}
                    },
                    time = 60
                },
                max_level = "infinite",
                upgrade = "true",
                order = "e-n-m"
            }
        })
    end

    -- Adds bobmods logistic science pack to the research.
    if data.raw.tool["logistic-science-pack"] then
            data.raw.technology["character-logistic-trash-slots-3"].unit.ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1}, {"logistic-science-pack", 1}}
            data.raw.technology["inserter-capacity-bonus-8"].unit.ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1}, {"high-tech-science-pack", 1}, {"logistic-science-pack", 1}, {"space-science-pack", 1}}
            data.raw.technology["worker-robots-speed-6"].unit.ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1}, {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"logistic-science-pack", 1}, {"space-science-pack", 1}}
            data.raw.technology["worker-robots-storage-5"].unit.ingredients = {{"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1}, {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"logistic-science-pack", 1}, {"space-science-pack", 1}}
    end

end