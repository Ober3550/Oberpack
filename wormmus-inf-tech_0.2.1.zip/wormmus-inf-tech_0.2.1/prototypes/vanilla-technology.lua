if modSetting("wit-research-disablemodresearch").value ~= "Disabled" then

    data:extend({

        {
            type = "technology",
            name = "bullet-speed-7",
            icon = "__base__/graphics/technology/bullet-damage.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "gun-speed",
                    ammo_category = "bullet",
                    modifier = 0.4
                }
            },
            prerequisites = {"bullet-speed-6"},
            unit =
            {
                count_formula = "(L-6)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"military-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "e-l-g"
        },

        {
            type = "technology",
            name = "cannon-shell-speed-6",
            icon = "__base__/graphics/technology/cannon-speed.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "gun-speed",
                    ammo_category = "cannon-shell",
                    modifier = 1
                }
            },
            prerequisites = {"cannon-shell-speed-5"},
            unit =
            {
                count_formula = "2^(L-5)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"military-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "e-k-l"
        },

        {
            type = "technology",
            name = "laser-turret-speed-8",
            icon = "__base__/graphics/technology/laser-turret-speed.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "gun-speed",
                    ammo_category = "laser-turret",
                    modifier = 1
                }
            },
            prerequisites = {"laser-turret-speed-7"},
            unit =
            {
                count_formula = "(L-7)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"military-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "e-n-o"
        },

        {
            type = "technology",
            name = "rocket-speed-8",
            icon = "__base__/graphics/technology/rocket-speed.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "gun-speed",
                    ammo_category = "rocket",
                    modifier = 1
                }
            },
            prerequisites = {"rocket-speed-7"},
            unit =
            {
                count_formula = "(L-7)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"military-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "e-j-o"
        },

        {
            type = "technology",
            name = "shotgun-shell-speed-7",
            icon = "__base__/graphics/technology/shotgun-shell-speed.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "gun-speed",
                    ammo_category = "shotgun-shell",
                    modifier = 0.4
                }
            },
            prerequisites = {"shotgun-shell-speed-6"},
            unit =
            {
                count_formula = "(L-6)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"military-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "e-n-m"
        },

        {
            type = "technology",
            name = "worker-robots-storage-4",
            icon = "__base__/graphics/technology/worker-robots-storage.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "worker-robot-storage",
                    modifier = 1
                }
            },
            prerequisites = {"worker-robots-storage-3"},
            unit =
            {
                count = 750,
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"production-science-pack", 1},
                    {"high-tech-science-pack", 1}
                },
                time = 60
            },
        upgrade = true,
        order = "c-k-g-d"
        },

        {
            type = "technology",
            name = "worker-robots-storage-5",
            icon = "__base__/graphics/technology/worker-robots-storage.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "worker-robot-storage",
                    modifier = 1
                }
            },
            prerequisites = {"worker-robots-storage-4"},
            unit =
            {
                count_formula = "(L-4)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"production-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
        upgrade = true,
        max_level = "infinite",
        order = "c-k-g-e"
        },

        {
            type = "technology",
            name = "character-logistic-trash-slots-3",
            icon = "__base__/graphics/technology/character-logistic-trash-slots.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "character-logistic-trash-slots",
                    modifier = 6
                }
            },
            prerequisites = {"character-logistic-trash-slots-2"},
            unit =
            {
                count_formula = "100*L",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"high-tech-science-pack", 1},
                    {"production-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 30
            },
            max_level = 6,
            upgrade = true,
            order = "c-k-f-c"
        },

        {
            type = "technology",
            name = "research-speed-7",
            icon = "__base__/graphics/technology/research-speed.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "laboratory-speed",
                    modifier = 1
                }
            },
            prerequisites = {"research-speed-6"},
            unit =
            {
                count_formula = "(L-6)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"production-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 30
            },
            max_level = "infinite",
            upgrade = true,
            order = "c-m-e"
        },

        {
            type = "technology",
            name = "braking-force-8",
            icon = "__base__/graphics/technology/braking-force.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "train-braking-force-bonus",
                    modifier = 0.25
                }
            },
            prerequisites = {"braking-force-7"},
            unit =
            {
                count_formula = "(L-7)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"production-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 60
            },
            max_level = "infinite",
            upgrade = true,
            order = "b-f-h"
        },

        {
            type = "technology",
            name = "inserter-capacity-bonus-8",
            icon = "__base__/graphics/technology/inserter-capacity.png",
            icon_size = 128,
            effects =
            {
                {
                    type = "stack-inserter-capacity-bonus",
                    modifier = 2
                }
            },
            prerequisites = {"inserter-capacity-bonus-7"},
            unit =
            {
                count_formula = "(L-7)*1000",
                ingredients =
                {
                    {"science-pack-1", 1},
                    {"science-pack-2", 1},
                    {"science-pack-3", 1},
                    {"production-science-pack", 1},
                    {"high-tech-science-pack", 1},
                    {"space-science-pack", 1}
                },
                time = 30
            },
            max_level = "infinite",
            upgrade = true,
            order = "c-o-i"
        }

    })

    if mods["boblogistics"] then

        data:extend({
            {
                type = "technology",
                name = "character-logistic-slots-6",
                icon = "__base__/graphics/technology/character-logistic-slots.png",
                icon_size = 128,
                effects =
                {
                    {
                        type = "character-logistic-slots",
                        modifier = 6
                    }
                },
                prerequisites = {"character-logistic-slots-5"},
                unit =
                {
                    count_formula = "1000*L",
                    ingredients =
                    {
                        {"science-pack-1", 1},
                        {"science-pack-2", 1},
                        {"science-pack-3", 1},
                        {"production-science-pack", 1},
                        {"high-tech-science-pack", 1},
                    },
                    time = 60
                },
                max_level = 9,
                upgrade = true,
                order = "c-k-e-f"
            },

            {
                type = "technology",
                name = "character-logistic-slots-10",
                icon = "__base__/graphics/technology/character-logistic-slots.png",
                icon_size = 128,
                effects =
                {
                    {
                        type = "character-logistic-slots",
                        modifier = 6
                    }
                },
                prerequisites = {"character-logistic-slots-6"},
                unit =
                {
                    count_formula = "1000*L",
                    ingredients =
                    {
                        {"science-pack-1", 1},
                        {"science-pack-2", 1},
                        {"science-pack-3", 1},
                        {"production-science-pack", 1},
                        {"high-tech-science-pack", 1},
                        {"space-science-pack", 1}
                    },
                    time = 60
                },
                max_level = 15,
                upgrade = true,
                order = "c-k-e-j"
            }

        })

    end

end