pack_set_nc =
{
    {"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1},
    {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}

non_combat_bobs =
{
    {"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1},
    {"logistic-science-pack", 1}, {"production-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}

pack_set_c =
{
    {"science-pack-1", 1}, {"science-pack-2", 1}, {"science-pack-3", 1},
    {"military-science-pack", 1}, {"high-tech-science-pack", 1}, {"space-science-pack", 1}
}
