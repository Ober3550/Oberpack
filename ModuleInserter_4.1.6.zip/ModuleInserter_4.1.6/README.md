Sick of having to put dozens of modules in your drills, assemblers, etc. by hand?

Configure ModuleInserter with a setup for machines, mark the area and watch your Pocketbots do the hard work

Click the buttons(grey squares) to set what module should go into which entity. To remove entities/modules simply right click.
To clear modules from entities only set the entity without modules.
Craft the module inserter item (it's where blueprints/deconstruction planner are), mark the area where your machines are and watch your bots.

Notes:
    Modules will first be taken from your inventory, if you don't have enough it will take them from the logistics network (for entities in logistics range only). The fake entity that is used to make the bots fly to the machine is inserted into your inventory. So it will only work if you have a personal roboport and a couple free slots in your inventory.