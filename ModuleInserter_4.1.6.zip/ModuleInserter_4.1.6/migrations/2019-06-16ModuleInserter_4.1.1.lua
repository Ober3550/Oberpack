--local mod_gui = require '__core__/lualib/mod-gui'
global.proxies = global.proxies or {}
global.to_create = global.to_create or {}
