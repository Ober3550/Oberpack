global.proxies = global.proxies or {}
global.to_create = global.to_create or {}
