
-- EXECUTE OVERRIDES
if not angelsmods.refining then
	angelsmods.functions.update_autoplace()
	resource_generator.finalise_resource_autoplace()
end
