local basespeed = 1/32

--Using recursion yall
local function set_speed(entity,name,speed)
    if data.raw[entity][name].speed then
        data.raw[entity][name].speed = basespeed * (2^(speed-1))
    end
    if data.raw[entity][name].next_upgrade then
        set_speed(entity,data.raw[entity][name].next_upgrade,speed+1)
    end
end
start_name = {"transport-belt","underground-belt","splitter","deadlock-loader-1"}
if mods.boblogistics then
    if settings.startup["bobmods-logistics-beltoverhaul"].value then
        start_name = {"basic-transport-belt","basic-underground-belt","basic-splitter","deadlock-loader-0"}
        basespeed = 1/64
    end
end

set_speed("transport-belt",start_name[1],1)
set_speed("underground-belt",start_name[2],1)
set_speed("splitter",start_name[3],1)
if mods.DeadlockLoaders then
        set_speed("loader",start_name[4],1)
end


    

