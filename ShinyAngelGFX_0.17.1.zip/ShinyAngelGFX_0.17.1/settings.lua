data:extend(
{
  {
    type = "bool-setting",
    name = "usecoloricons",
    setting_type = "startup",
    default_value = true,
  },
  {
    type = "bool-setting",
    name = "usecolorbars",
    setting_type = "startup",
    default_value = true,
  }
  }
  )
  