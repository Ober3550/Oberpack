data:extend{
  {
    type = "bool-setting",
    name = "miniloader-energy-usage",
    setting_type = "startup",
    default_value = true,
    order = "miniloader-energy-usage",
  },

  {
    type = "bool-setting",
    name = "miniloader-snapping",
    setting_type = "runtime-global",
    default_value = true,
    order = "miniloader-snapping",
  },
}