data.raw.technology['advanced-electronics-3'].unit =
{
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 30,
      count = 100
}
--data.raw.technology["electronics-machine-1"].enabled = false
--data.raw.technology["electronics-machine-2"].enabled = false
--data.raw.technology["electronics-machine-3"].enabled = false
data.raw.technology["effect-transmission-2"].enabled = false
data.raw.technology["effect-transmission-3"].enabled = false
data.raw.technology["water-bore-1"].enabled = false
data.raw.technology["water-bore-2"].enabled = false
data.raw.technology["water-bore-3"].enabled = false
data.raw.technology["water-bore-4"].enabled = false
data.raw.technology["bio-processing-alien"].enabled = false
data.raw.technology["bio-processing-paste"].enabled = false
data.raw.technology["angels-coolant-1"].effects =
{
    {
        type = "unlock-recipe",
        recipe = "cooling-tower"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-used-filtration-1"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-300"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-steam"
    }
}
data.raw.technology["uranium-ammo"].prerequisites = {"ober-uranium-processing"}
data.raw.technology["uranium-ammo"].unit = 
{
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"military-science-pack",1}
	  },
      time = 30
}
data.raw.technology["nuclear-power"].prerequisites = 
{
    "ober-uranium-processing",
    "bob-steam-power-3"
}
data.raw.technology["nuclear-power"].effects = 
{
      {
        type = "unlock-recipe",
        recipe = "nuclear-reactor"
      },
      {
        type = "unlock-recipe",
        recipe = "uranium-fuel-cell"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-exchanger"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-pipe"
      },
      {
        type = "unlock-recipe",
        recipe = "steam-turbine"
      },
}
data.raw.technology["nuclear-power"].unit = 
{
      count = 1000,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-1"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-2"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  {"high-tech-science-pack",1},
	  },
      time = 30
}
data:extend({
    {
    type = "technology",
    name = "ober-uranium-processing",
    icon = "__ScienceOberhaul__/graphics/uranium_processing.png",
	icon_size = 128,
	prerequisites =
    {
	"advanced-electronics","concrete"
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "uranium-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "centrifuge"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  },
      time = 30
    },
    order = "c-a",
    }
})

