data.raw.technology['advanced-electronics-3'].unit =
{
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 30,
      count = 100
}
data.raw.technology["electronics-machine-1"].enabled = false
data.raw.technology["electronics-machine-2"].enabled = false
data.raw.technology["electronics-machine-3"].enabled = false
data.raw.technology["water-bore-1"].enabled = false
data.raw.technology["water-bore-2"].enabled = false
data.raw.technology["water-bore-3"].enabled = false
data.raw.technology["water-bore-4"].enabled = false
data.raw.technology["bio-processing-alien"].enabled = false
data.raw.technology["bio-processing-paste"].enabled = false
data.raw.technology["angels-coolant-1"].effects =
{
    {
        type = "unlock-recipe",
        recipe = "cooling-tower"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-used-filtration-1"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-300"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-steam"
    }
}
data.raw.technology["uranium-ammo"].prerequisites = {"ober-uranium-processing"}
data.raw.technology["uranium-ammo"].unit = 
{
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"military-science-pack",1}
	  },
      time = 30
}
data.raw.technology["nuclear-power"].prerequisites = 
{
    "ober-uranium-processing",
    "bob-steam-power-3"
}
data.raw.technology["nuclear-power"].effects = 
{
      {
        type = "unlock-recipe",
        recipe = "nuclear-reactor"
      },
      {
        type = "unlock-recipe",
        recipe = "uranium-fuel-cell"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-exchanger"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-pipe"
      },
      {
        type = "unlock-recipe",
        recipe = "steam-turbine"
      },
}
data.raw.technology["nuclear-power"].unit = 
{
      count = 1000,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-1"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-2"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  {"high-tech-science-pack",1},
	  },
      time = 30
}
--Make Lazy Bastard Possible
data.raw.technology["basic-automation"].unit = {count=1,ingredients={{"science-pack-1",1}},time=30}

data:extend({
    {
    type = "technology",
    name = "ober-uranium-processing",
    icon = "__ScienceOberhaul__/graphics/uranium_processing.png",
	icon_size = 128,
	prerequisites =
    {
	"advanced-electronics","concrete"
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "uranium-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "centrifuge"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  },
      time = 30
    },
    order = "c-a",
    }
})
if aai_industry then
    data.raw.lab["burner-lab"].inputs = {"science-pack-1"}
end
data.raw.lab["lab"].inputs = {"science-pack-1","science-pack-2","science-pack-3","logistic-science-pack","production-science-pack","token-bio"}
bobmods.lib.tech.add_recipe_unlock("advanced-electronics-2", "production-science-pack")
bobmods.lib.tech.add_recipe_unlock("advanced-electronics-3", "high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-electronics-2","high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-material-processing-2","production-science-pack")
data.raw.technology["advanced-research"].prerequisites = {"advanced-electronics-2","bob-logistics-4"}
bobmods.lib.tech.add_new_science_pack("advanced-research","production-science-pack",1)
bobmods.lib.tech.add_new_science_pack("advanced-research","logistic-science-pack",1)
data.raw.technology["advanced-electronics-3"].prerequisites = {"advanced-electronics-2","advanced-research"}
