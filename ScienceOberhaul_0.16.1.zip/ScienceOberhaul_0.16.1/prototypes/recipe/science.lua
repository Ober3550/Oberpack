--Clear Science Pack Recipes
data.raw.recipe["science-pack-1"].ingredients = nil
data.raw.recipe["science-pack-2"].ingredients = nil
data.raw.recipe["science-pack-3"].ingredients = nil
data.raw.recipe["production-science-pack"].ingredients = nil
data.raw.recipe["high-tech-science-pack"].ingredients = nil

data.raw.recipe['science-pack-1'].ingredients = {
    {"iron-gear-wheel",1},
    {"copper-plate",2}
}

data.raw.recipe["science-pack-2"].result_count = 2
data.raw.recipe['science-pack-2'].ingredients = {
    {"fast-inserter",1},
    {"small-electric-pole",1}
}

data.raw.recipe['science-pack-3'].ingredients = {
    {"advanced-circuit",4},
    {"steel-axe",2},
    {"gold-plate",4},
    {"aluminium-plate",4}
}

data.raw.recipe['military-science-pack'].ingredients = {
    {"gunmetal-alloy",4},
    {"invar-alloy",3},
    {"grenade",1}
}

data.raw.recipe["logistic-science-pack"].ingredients = {
    {"car", 1},
    {"express-transport-belt", 1},
    {"flying-robot-frame", 1},
    {"brass-chest", 1}
}

data.raw.recipe['production-science-pack'].ingredients = {
    {"bob-pump-4",1},
    {"cobalt-axe",2},
    {"processing-unit",4},
    {"sapphire-5",2},
    {"amethyst-5",2}
}

data.raw.recipe['high-tech-science-pack'].ingredients = {
    {"angels-wire-silver",30},
    {"tungsten-pipe-to-ground",2},
    {"electrum-alloy",8},
    {"advanced-processing-unit",4},
    {"uranium-238",5},
    {"rubber",10}
}

data.raw.recipe["rocket-control-unit"].ingredients = {
    {"advanced-processing-unit",1},
    {"productivity-module-2",1}
}