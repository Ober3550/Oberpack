-- Vanilla Belts
-- Changes Speed 
base_speed = data.raw["transport-belt"]["transport-belt"].speed


data.raw["transport-belt"]["express-transport-belt"].speed = 4 * base_speed

data.raw["underground-belt"]["express-underground-belt"].speed = 4 * base_speed

data.raw["splitter"]["express-splitter"].speed = 4 * base_speed

-- Changes Recipe
--[[
data.raw.recipe["express-transport-belt"].ingredients = {
    {"fast-transport-belt",2},
    {"titanium-gear-wheel",2},
    {"titanium-bearing",1}
}
data.raw.recipe["express-underground-belt"].ingredients = {
    {"fast-underground-belt",4},
    {"titanium-gear-wheel",10},
    {"titanium-bearing",1}
}
data.raw.recipe["express-splitter"].ingredients = {
    {"fast-splitter",2},
    {"titanium-gear-wheel",4},
    {"advanced-circuit",10},
    {"titanium-bearing",1}
}
--]]
-- Bobs Belts
-- Changes Speed
data.raw["transport-belt"]["turbo-transport-belt"].speed = 8 * base_speed

data.raw["underground-belt"]["turbo-underground-belt"].speed = 8 * base_speed

data.raw["splitter"]["turbo-splitter"].speed = 8 * base_speed
 
-- Changes Recipe
data.raw.recipe["turbo-transport-belt"].ingredients = {
    {"express-transport-belt",2},
    {"titanium-gear-wheel",4},
    {"titanium-bearing",2}
}
data.raw.recipe["turbo-underground-belt"].ingredients = {
    {"express-underground-belt",4},
    {"titanium-gear-wheel",20},
    {"titanium-bearing",2}
}
data.raw.recipe["turbo-splitter"].ingredients = {
    {"express-splitter",2},
    {"titanium-gear-wheel",4},
    {"processing-unit",10},
    {"titanium-bearing",2}
}
data.raw["transport-belt"]['ultimate-transport-belt'].speed = 16 * base_speed

data.raw["underground-belt"]['ultimate-underground-belt'].speed = 16 * base_speed

data.raw["splitter"]['ultimate-splitter'].speed = 16 * base_speed
 
-- Changes Recipe
data.raw.recipe['ultimate-transport-belt'].ingredients = {
    {"turbo-transport-belt",2},
    {"nitinol-gear-wheel",4},
    {"nitinol-bearing",2}
}
data.raw.recipe['ultimate-underground-belt'].ingredients = {
    {"turbo-underground-belt",4},
    {"nitinol-gear-wheel",20},
    {"nitinol-bearing",2}
}
data.raw.recipe['ultimate-splitter'].ingredients = {
    {"turbo-splitter",2},
    {"nitinol-gear-wheel",4},
    {"advanced-processing-unit",10},
    {"nitinol-bearing",2}
}
data.raw.technology["bob-logistics-5"].enabled = false
data.raw.technology["ultimate-miniloader"].enabled = false
data.raw.recipe['ultimate-transport-belt'].hidden = true
data.raw.recipe['ultimate-underground-belt'].hidden = true
data.raw.recipe['ultimate-splitter'].hidden = true