--Misc Changes
data.raw.recipe['beacon-2'].hidden = true
data.raw.recipe['beacon-3'].hidden = true
data.raw.recipe["red-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.recipe["green-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.recipe["bob-resin-wood"].hidden = true
data.raw.recipe["flying-robot-frame"].normal.ingredients = 
{
      {"electric-engine-unit", 2},
      {"battery", 2},
      {"electronic-circuit", 2},
      {"steel-plate", 4},
}
data.raw.recipe["lab-2"].ingredients = {
    {"express-stack-inserter", 2},
    {"turbo-transport-belt",2},
    {"advanced-processing-unit",2},
    {"lab",1}
}

--Omega Drill
data.raw.technology["omega-drill"].prerequisites = { "bob-logistics-4", "bob-drills-4"}
data.raw.technology["omega-drill"].unit = {
      count = 300,
      ingredients = {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
	{"science-pack-3", 1},
	{"production-science-pack", 1},
	{"high-tech-science-pack", 1}
      },
      time = 30
}
data.raw["mining-drill"]["omega-drill"].module_specification = 
{
      module_slots = 10,
      module_info_icon_shift = {0, 0.5},
      module_info_multi_row_initial_height_modifier = -0.3
}
data.raw.recipe["omega-drill"].ingredients = 
{
    {"electric-engine-unit",25},
    {"turbo-transport-belt",10},
    {"bob-mining-drill-4",25},
    {"advanced-processing-unit",25},
    {"tungsten-gear-wheel",20},
    {"nitinol-bearing",10}

}
data.raw.item["nuclear-fuel"].stack_size = 2
data.raw.recipe["heat-exchanger"].ingredients = {
    {"boiler-4",1},
    {"titanium-pipe",20},
    {"copper-plate",100},
    {"steel-plate",100},
}
data.raw.recipe["steam-turbine"].ingredients = {
    {"steam-engine-4",1},
    {"titanium-pipe",20},
    {"copper-plate",50},
    {"iron-gear-wheel",100},
}
-- Washing plant sulfur byproduct

local washing_fluid_box = {
 
production_type = 'output',
  
pipe_covers = pipecoverspictures(),
  
base_level = 1,
  pipe_connections = {{ position = {-3, 0} }}

}

table.insert(data.raw['assembling-machine']['washing-plant'].fluid_boxes, washing_fluid_box)

table.insert(data.raw['assembling-machine']['washing-plant-2'].fluid_boxes, washing_fluid_box)

table.insert(data.raw.recipe['washing-1'].results,
  {type = "fluid", name = "gas-hydrogen-sulfide", amount = 20}
)

data.raw.recipe["water-pump"].hidden = true
data.raw.recipe["water-pump-2"].hidden = true
data.raw.recipe["water-pump-3"].hidden = true
data.raw.recipe["water-pump-4"].hidden = true

--Trains
data.raw["cargo-wagon"]["cargo-wagon"].inventory_size = 20
data.raw["cargo-wagon"]["bob-cargo-wagon-2"].inventory_size = 40
data.raw["cargo-wagon"]["bob-cargo-wagon-3"].inventory_size = 60
data.raw.recipe["bob-fluid-wagon-2"].hidden = true
data.raw.recipe["bob-fluid-wagon-3"].hidden = true

data.raw["cargo-wagon"]["bob-armoured-cargo-wagon"].inventory_size = 40
data.raw["cargo-wagon"]["bob-armoured-cargo-wagon-2"].inventory_size = 60
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon"].total_capacity = 75000
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon-2"].total_capacity = 75000
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon"].capacity = 75000
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon-2"].capacity = 75000

data.raw["cargo-wagon"]["bob-armoured-cargo-wagon"].weight = 1000
data.raw["cargo-wagon"]["bob-armoured-cargo-wagon-2"].weight = 1000
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon"].weight = 3000
data.raw["fluid-wagon"]["bob-armoured-fluid-wagon-2"].weight = 3000

--Cooling Tower
data.raw.recipe["coolant-used-filtration-1"].ingredients =
{
    {type="fluid", name="liquid-coolant-used", amount=1000, maximum_temperature = 200},
    {type="item", name="filter-coal", amount=1},
}
data.raw.recipe["coolant-used-filtration-1"].results =
{	  
    {type="fluid", name="liquid-coolant", amount=990, temperature = 25},
    {type="item", name="filter-frame", amount=1},
}
data.raw.recipe["coolant-used-filtration-2"].ingredients =
{
    {type="fluid", name="liquid-coolant-used", amount=1000, maximum_temperature = 200},
    {type="item", name="filter-ceramic", amount=1},
}
data.raw.recipe["coolant-used-filtration-2"].results =
{
    {type="fluid", name="liquid-coolant", amount=1000, temperature = 25},
    {type="item", name="filter-ceramic-used", amount=1},
}
data.raw.recipe["coolant-cool-200"].hidden = true
data.raw.recipe["coolant-cool-100"].hidden = true