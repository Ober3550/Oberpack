data.raw.technology["chest-4"].enabled = false
data.raw.technology["chest-5"].enabled = false
data.raw.technology["chest-6"].enabled = false
data.raw.technology["logistic-system-2"].enabled = false
data.raw.technology["logistic-system-3"].enabled = false
data.raw.technology["logistic-robotics"].effects = {
    {
        type = "unlock-recipe",
        recipe = "logistic-chest-passive-provider"
    },
    {
        type = "unlock-recipe",
        recipe = "logistic-chest-storage"
    },
    {
        type = "unlock-recipe",
        recipe = "logistic-robot"
    }
}
bobmods.lib.tech.add_new_science_pack("logistic-system","logistic-science-pack",1)
bobmods.lib.tech.add_recipe_unlock("logistic-system","logistic-chest-requester")
bobmods.lib.tech.add_new_science_pack("logistic-silos","logistic-science-pack",1)
bobmods.lib.tech.add_new_science_pack("logistic-silos","production-science-pack",1)
bobmods.lib.tech.add_new_science_pack("angels-logistic-warehouses","logistic-science-pack",1)
bobmods.lib.tech.add_new_science_pack("angels-logistic-warehouses","production-science-pack",1)
bobmods.lib.tech.add_new_science_pack("angels-logistic-warehouses","high-tech-science-pack",1)