require('prototypes.config.belts')
