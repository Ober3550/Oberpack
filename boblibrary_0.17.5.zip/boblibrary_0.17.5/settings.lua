data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-lib-resource-generator",
    setting_type = "startup",
    default_value = false,
  },
}
)
