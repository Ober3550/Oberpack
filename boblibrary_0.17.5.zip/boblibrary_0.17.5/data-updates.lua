if resource_generator then
  resource_generator.finalise_resource_autoplace()
end
