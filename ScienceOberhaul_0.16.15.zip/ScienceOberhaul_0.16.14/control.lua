script.on_init(function()
game.difficulty_settings.technology_price_multiplier=settings.startup["tech-multiplier"].value
end)