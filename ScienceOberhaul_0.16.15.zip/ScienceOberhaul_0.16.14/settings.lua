data:extend({
   {
      type = "double-setting",
      name = "tech-multiplier",
      setting_type = "startup",
      default_value = 10,
   },
})