if mods.bobelectronics then
data.raw.technology['advanced-electronics-3'].unit =
{
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 30,
      count = 100
}
end
--Make Lazy Bastard Possible
if mods["aai-industry"] then
  data.raw.technology["basic-automation"].unit = {count=1,ingredients={{"science-pack-1",1}},time=30}
  data.raw.lab["burner-lab"].inputs = {"science-pack-1"}
end

data.raw.lab["lab"].inputs = {"science-pack-1","science-pack-2","science-pack-3","military-science-pack","logistic-science-pack","production-science-pack","token-bio"}

bobmods.lib.tech.add_recipe_unlock("advanced-electronics-2", "production-science-pack")
bobmods.lib.tech.add_recipe_unlock("advanced-electronics-3", "high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-electronics-2","high-tech-science-pack")
bobmods.lib.tech.remove_recipe_unlock("advanced-material-processing-2","production-science-pack")
data.raw.technology["advanced-research"].prerequisites = {"advanced-electronics-2","bob-logistics-4"}
bobmods.lib.tech.add_new_science_pack("advanced-research","production-science-pack",1)
bobmods.lib.tech.add_new_science_pack("advanced-research","logistic-science-pack",1)
data.raw.technology["advanced-electronics-3"].prerequisites = {"advanced-electronics-2","advanced-research"}
data.raw.technology["nitinol-processing"].unit.ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
          {"logistic-science-pack", 1}}
data.raw.technology["power-armor-2"].unit.ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
          {"military-science-pack", 1}}