data:extend(
{
  {
    type = "recipe",
    name = "bob-logistic-robot-2",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-logistic-robot-2"
  },

  {
    type = "recipe",
    name = "bob-logistic-robot-3",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-logistic-robot-3"
  },

  {
    type = "recipe",
    name = "bob-logistic-robot-4",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-logistic-robot-4"
  },

  {
    type = "recipe",
    name = "bob-logistic-robot-5",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-logistic-robot-5"
  },


  {
    type = "recipe",
    name = "bob-construction-robot-2",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-construction-robot-2"
  },

  {
    type = "recipe",
    name = "bob-construction-robot-3",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-construction-robot-3"
  },

  {
    type = "recipe",
    name = "bob-construction-robot-4",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-construction-robot-4"
  },

  {
    type = "recipe",
    name = "bob-construction-robot-5",
    enabled = false,
    ingredients =
    {
    },
    result = "bob-construction-robot-5"
  },
}
)





