if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.pressuretanks then angelsmods.addons.pressuretanks = {} end

require("prototypes.buildings.pressure-tanks")

require("prototypes.recipes.pressure-tanks")

require("prototypes.technology.pressure-tanks-technology")