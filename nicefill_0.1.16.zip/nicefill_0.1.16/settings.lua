data:extend({
    {
        type = "bool-setting",
        name = "nicefill-dowaterblending",
        setting_type = "runtime-global",
        default_value = true,
        order = 1
    }
})
