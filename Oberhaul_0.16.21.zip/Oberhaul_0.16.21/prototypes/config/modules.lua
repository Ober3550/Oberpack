if mods.bobmodules then
--Beacon Changes
data.raw.recipe['beacon-2'].hidden = true
data.raw.recipe['beacon-3'].hidden = true
data.raw.technology["effect-transmission-2"].enabled = false
data.raw.technology["effect-transmission-3"].enabled = false

if data.raw.technology["pollution-clean-module"] then
for index=1,8,1 do
    data.raw.technology["pollution-clean-module-"..index].enabled = false
    data.raw.technology["pollution-create-module-"..index].enabled = false
    data.raw.recipe["pollution-clean-module-"..index].enabled = false
    data.raw.recipe["pollution-create-module-"..index].enabled = false
end
end


--Module Costs
data.raw.recipe["module-contact"].normal.result_count = 2
data.raw.recipe["module-processor-board"].normal.result_count = 1
data.raw.recipe["module-processor-board"].normal.energy_required = 5
data.raw.recipe["module-processor-board-2"].normal.result_count = 1
data.raw.recipe["module-processor-board-2"].normal.energy_required = 10
data.raw.recipe["module-processor-board-3"].normal.result_count = 1
data.raw.recipe["module-processor-board-3"].normal.energy_required = 15

data.raw.recipe["speed-processor"].normal.energy_required = 5
data.raw.recipe["speed-processor-2"].normal.energy_required = 10
data.raw.recipe["speed-processor-3"].normal.energy_required = 15

data.raw.recipe["effectivity-processor"].normal.energy_required = 5
data.raw.recipe["effectivity-processor-2"].normal.energy_required = 10
data.raw.recipe["effectivity-processor-3"].normal.energy_required = 15

data.raw.recipe["productivity-processor"].normal.energy_required = 5
data.raw.recipe["productivity-processor-2"].normal.energy_required = 10
data.raw.recipe["productivity-processor-3"].normal.energy_required = 15
if settings.startup["modules-use-circuits"].value then
for _, recipes in pairs({"speed-","productivity-","effectivity-"}) do
    for index=1,8,1 do
        bobmods.lib.recipe.replace_ingredient(recipes.."module-"..index,recipes.."processor-2","processing-unit")
        bobmods.lib.recipe.replace_ingredient(recipes.."module-"..index,recipes.."processor-3","advanced-processing-unit")
    end
end
end
--Modules
bobmods.lib.recipe.add_ingredient("speed-module-2",{"speed-module",1})
bobmods.lib.recipe.add_ingredient("speed-module-3",{"speed-module-2",1})
bobmods.lib.recipe.add_ingredient("speed-module-4",{"speed-module-3",1})
bobmods.lib.recipe.add_ingredient("speed-module-5",{"speed-module-4",1})
bobmods.lib.recipe.add_ingredient("speed-module-6",{"speed-module-5",1})
bobmods.lib.recipe.add_ingredient("speed-module-7",{"speed-module-6",1})
bobmods.lib.recipe.add_ingredient("speed-module-8",{"speed-module-7",1})

bobmods.lib.recipe.add_ingredient("productivity-module-2",{"productivity-module",1})
bobmods.lib.recipe.add_ingredient("productivity-module-3",{"productivity-module-2",1})
bobmods.lib.recipe.add_ingredient("productivity-module-4",{"productivity-module-3",1})
bobmods.lib.recipe.add_ingredient("productivity-module-5",{"productivity-module-4",1})
bobmods.lib.recipe.add_ingredient("productivity-module-6",{"productivity-module-5",1})
bobmods.lib.recipe.add_ingredient("productivity-module-7",{"productivity-module-6",1})
bobmods.lib.recipe.add_ingredient("productivity-module-8",{"productivity-module-7",1})

bobmods.lib.recipe.add_ingredient("effectivity-module-2",{"effectivity-module",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-3",{"effectivity-module-2",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-4",{"effectivity-module-3",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-5",{"effectivity-module-4",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-6",{"effectivity-module-5",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-7",{"effectivity-module-6",1})
bobmods.lib.recipe.add_ingredient("effectivity-module-8",{"effectivity-module-7",1})

bobmods.lib.recipe.add_ingredient("speed-module-3",{"module-contact",5})
bobmods.lib.recipe.add_ingredient("productivity-module-3",{"module-contact",5})
bobmods.lib.recipe.add_ingredient("effectivity-module-3",{"module-contact",5})

bobmods.lib.recipe.replace_ingredient("speed-module-5", "ruby-5", "emerald-5")
bobmods.lib.recipe.replace_ingredient("productivity-module-5", "ruby-5", "emerald-5")
bobmods.lib.recipe.replace_ingredient("effectivity-module-5", "ruby-5", "emerald-5")

bobmods.lib.recipe.replace_ingredient("speed-module-6", "emerald-5", "amethyst-5")
bobmods.lib.recipe.replace_ingredient("productivity-module-6", "emerald-5", "amethyst-5")
bobmods.lib.recipe.replace_ingredient("effectivity-module-6", "emerald-5", "amethyst-5")

data.raw.recipe["speed-module"].energy_required   = 10
data.raw.recipe["speed-module-2"].energy_required = 20
data.raw.recipe["speed-module-3"].energy_required = 20
data.raw.recipe["speed-module-4"].energy_required = 40
data.raw.recipe["speed-module-5"].energy_required = 40
data.raw.recipe["speed-module-6"].energy_required = 80
data.raw.recipe["speed-module-7"].energy_required = 80
data.raw.recipe["speed-module-8"].energy_required = 160

data.raw.recipe["productivity-module"].energy_required   = 10
data.raw.recipe["productivity-module-2"].energy_required = 20
data.raw.recipe["productivity-module-3"].energy_required = 20
data.raw.recipe["productivity-module-4"].energy_required = 40
data.raw.recipe["productivity-module-5"].energy_required = 40
data.raw.recipe["productivity-module-6"].energy_required = 80
data.raw.recipe["productivity-module-7"].energy_required = 80
data.raw.recipe["productivity-module-8"].energy_required = 160

data.raw.recipe["effectivity-module"].energy_required   = 10
data.raw.recipe["effectivity-module-2"].energy_required = 20
data.raw.recipe["effectivity-module-3"].energy_required = 20
data.raw.recipe["effectivity-module-4"].energy_required = 40
data.raw.recipe["effectivity-module-5"].energy_required = 40
data.raw.recipe["effectivity-module-6"].energy_required = 80
data.raw.recipe["effectivity-module-7"].energy_required = 80
data.raw.recipe["effectivity-module-8"].energy_required = 160

data.raw.module["speed-module"].module_effects =   {speed = {bonus = 1*0.1}, consumption = {bonus = 1*0.175}}
data.raw.module["speed-module-2"].module_effects = {speed = {bonus = 2*0.1}, consumption = {bonus = 2*0.175}}
data.raw.module["speed-module-3"].module_effects = {speed = {bonus = 3*0.1}, consumption = {bonus = 3*0.175}}
data.raw.module["speed-module-4"].module_effects = {speed = {bonus = 4*0.1}, consumption = {bonus = 4*0.175}}
data.raw.module["speed-module-5"].module_effects = {speed = {bonus = 5*0.1}, consumption = {bonus = 5*0.175}}
data.raw.module["speed-module-6"].module_effects = {speed = {bonus = 6*0.1}, consumption = {bonus = 6*0.175}}
data.raw.module["speed-module-7"].module_effects = {speed = {bonus = 7*0.1}, consumption = {bonus = 7*0.175}}
data.raw.module["speed-module-8"].module_effects = {speed = {bonus = 8*0.1}, consumption = {bonus = 8*0.175}}

data.raw.module["productivity-module"].module_effects =   {productivity = {bonus = 1*0.0375}, consumption = {bonus = 1*0.3}}
data.raw.module["productivity-module-2"].module_effects = {productivity = {bonus = 2*0.0375}, consumption = {bonus = 2*0.3}}
data.raw.module["productivity-module-3"].module_effects = {productivity = {bonus = 3*0.0375}, consumption = {bonus = 3*0.3}}
data.raw.module["productivity-module-4"].module_effects = {productivity = {bonus = 4*0.0375}, consumption = {bonus = 4*0.3}}
data.raw.module["productivity-module-5"].module_effects = {productivity = {bonus = 5*0.0375}, consumption = {bonus = 5*0.3}}
data.raw.module["productivity-module-6"].module_effects = {productivity = {bonus = 6*0.0375}, consumption = {bonus = 6*0.3}}
data.raw.module["productivity-module-7"].module_effects = {productivity = {bonus = 7*0.0375}, consumption = {bonus = 7*0.3}}
data.raw.module["productivity-module-8"].module_effects = {productivity = {bonus = 8*0.0375}, consumption = {bonus = 8*0.3}}

data.raw.module["productivity-module"].module_effects.speed =   {bonus = -1 * 0.15}
data.raw.module["productivity-module-2"].module_effects.speed = {bonus = -2 * 0.15}
data.raw.module["productivity-module-3"].module_effects.speed = {bonus = -3 * 0.15}
data.raw.module["productivity-module-4"].module_effects.speed = {bonus = -4 * 0.15}
data.raw.module["productivity-module-5"].module_effects.speed = {bonus = -5 * 0.15}
data.raw.module["productivity-module-6"].module_effects.speed = {bonus = -6 * 0.15}
data.raw.module["productivity-module-7"].module_effects.speed = {bonus = -7 * 0.15}
data.raw.module["productivity-module-8"].module_effects.speed = {bonus = -8 * 0.15}

data.raw.module["effectivity-module"].module_effects =   {consumption = {bonus = -1*0.3}}
data.raw.module["effectivity-module-2"].module_effects = {consumption = {bonus = -2*0.3}}
data.raw.module["effectivity-module-3"].module_effects = {consumption = {bonus = -3*0.4}}
data.raw.module["effectivity-module-4"].module_effects = {consumption = {bonus = -4*1}}
data.raw.module["effectivity-module-5"].module_effects = {consumption = {bonus = -5*1}}
data.raw.module["effectivity-module-6"].module_effects = {consumption = {bonus = -6*1}}
data.raw.module["effectivity-module-7"].module_effects = {consumption = {bonus = -7*1}}
data.raw.module["effectivity-module-8"].module_effects = {consumption = {bonus = -8*1}}
end