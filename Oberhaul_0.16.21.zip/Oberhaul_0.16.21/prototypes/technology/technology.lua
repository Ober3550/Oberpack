if mods.bobpower then
data.raw.technology["nuclear-power"].prerequisites = 
{
    "ober-uranium-processing",
    "bob-steam-power-2"
}
data.raw.technology["nuclear-power"].effects = 
{
      {
        type = "unlock-recipe",
        recipe = "nuclear-reactor"
      },
      {
        type = "unlock-recipe",
        recipe = "uranium-fuel-cell"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-exchanger"
      },
      {
        type = "unlock-recipe",
        recipe = "heat-pipe"
      },
      {
        type = "unlock-recipe",
        recipe = "steam-turbine"
      },
}
data.raw.technology["nuclear-power"].unit = 
{
      count = 1000,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-1"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-2"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  {"high-tech-science-pack",1},
	  },
      time = 30
}
end
data:extend({
    {
    type = "technology",
    name = "ober-uranium-processing",
    icon = "__Oberhaul__/graphics/uranium_processing.png",
	icon_size = 128,
	prerequisites =
    {
	"advanced-electronics","concrete"
    },
    effects =
    {
	  {
        type = "unlock-recipe",
        recipe = "uranium-processing"
      },
	  {
        type = "unlock-recipe",
        recipe = "centrifuge"
      },
    },
    unit =
    {
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  },
      time = 30
    },
    order = "c-a",
    }
})
data.raw.technology["power-armor-2"].unit.ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
          {"military-science-pack", 1}}

if mods["bobplates"] then
data.raw.technology["nitinol-processing"].unit.ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
          {"logistic-science-pack", 1}}

end