data:extend(
{
  {
    type = "item",
    name = "wooden-chest-medium",
    icon = "__Large-Chests__/graphics/icons/wooden-chest-plus.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "medium-chest",
    order = "c-m-1",
    place_result = "wooden-chest-medium",
    stack_size = 50
  },
  {
    type = "item",
    name = "iron-chest-medium",
    icon = "__Large-Chests__/graphics/icons/iron-chest-plus.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "medium-chest",
    order = "c-m-2",
    place_result = "iron-chest-medium",
    stack_size = 50
  },
  {
    type = "item",
    name = "steel-chest-medium",
    icon = "__Large-Chests__/graphics/icons/steel-chest-plus.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "medium-chest",
    order = "c-m-3",
    place_result = "steel-chest-medium",
    stack_size = 50
  },
  {
    type = "item",
    name = "wooden-chest-big",
    icon = "__Large-Chests__/graphics/icons/wooden-chest-plus2.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "big-chest",
    order = "c-ml-1",
    place_result = "wooden-chest-big",
    stack_size = 50
  },
  {
    type = "item",
    name = "iron-chest-big",
    icon = "__Large-Chests__/graphics/icons/iron-chest-plus2.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "big-chest",
    order = "c-ml-2",
    place_result = "iron-chest-big",
    stack_size = 50
  },
  {
    type = "item",
    name = "steel-chest-big",
    icon = "__Large-Chests__/graphics/icons/steel-chest-plus2.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "big-chest",
    order = "c-ml-3",
    place_result = "steel-chest-big",
    stack_size = 50
  },
}
)