circuit_connector_definitions["chest2x2"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 26, main_offset = util.by_pixel(3*2, 5.5*2), shadow_offset = util.by_pixel(7.5*2, 7.5*2), show_shadow = true },
  }
)
circuit_connector_definitions["chest3x3"] = circuit_connector_definitions.create
(
  universal_connector_template,
  {
    { variation = 26, main_offset = util.by_pixel(3*3, 5.5*3), shadow_offset = util.by_pixel(7.5*3, 7.5*3), show_shadow = true },
  }
)