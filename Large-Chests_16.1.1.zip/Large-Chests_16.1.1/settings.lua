data:extend({


	{
	    type = "bool-setting",
	    name = "large-chest-vertical",
	    description = "large-chest-vertical",
	    setting_type = "startup",
	    default_value = false,
	    order = "rana-largechest-a[recipes]-a",
	    per_user = false
	},
	{
	    type = "bool-setting",
	    name = "large-chest-horizontal",
	    description = "large-chest-horizontal",
	    setting_type = "startup",
	    default_value = true,
	    order = "rana-largechest-a[recipes]-b",
	    per_user = false
	},
	{
	    type = "bool-setting",
	    name = "large-chest-wood",
	    description = "large-chest-wood",
	    setting_type = "startup",
	    default_value = true,
	    order = "rana-largechest-a[recipes]-c",
	    per_user = false
	},
})
