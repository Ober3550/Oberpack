for i, player in ipairs(game.forces) do
    force.reset_recipes()
    force.reset_technologies()
    
    if force.technologies["chest-5"].researched then
        force.recipes["logistic-chest-buffer-medium"].enabled = true
    else
        force.recipes["logistic-chest-buffer-medium"].enabled = false
    end
    if force.technologies["chest-6"].researched then
        force.recipes["logistic-chest-buffer-big"].enabled = true
    else
        force.recipes["logistic-chest-buffer-big"].enabled = false
    end
end