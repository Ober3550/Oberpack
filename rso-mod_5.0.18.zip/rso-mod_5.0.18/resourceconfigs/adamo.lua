function fillAdamoConfig(config)
	config["adamo-carbon-natural-gas"] = {
		type="resource-liquid",
		minimum_amount=240000,
		allotment=70,
		spawns_per_region={min=1, max=3},
		richness={min=240000, max=400000},
		size={min=1, max=5},
		starting={richness=400000, size=1, probability=1},
		multi_resource_chance=0.6,
		multi_resource={
			["crude-oil"] = 2
		}
	}
end