function fillZzzModdersSciencePackConfig(config)
	
	config["pixels"] = {
		type = "resource-ore",
		allotment = 40,
		spawns_per_region = {min=1, max=1},
		richness = 4000,
		size = {min=10, max=15},
	}

end