data.raw.technology["advanced-steam-power-1"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  },
      time = 30
}
data.raw.technology["advanced-steam-power-2"].unit = 
{
      count = 500,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"production-science-pack",1},
	  {"high-tech-science-pack",1},
	  },
      time = 30
}