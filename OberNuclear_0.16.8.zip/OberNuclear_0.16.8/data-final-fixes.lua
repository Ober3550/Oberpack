require('prototypes.populaterecipes')
if mods.bobwarfare then
	require('prototypes.bobwarfare')
end
if mods.bobpower then
	require('prototypes.bobpower')
end