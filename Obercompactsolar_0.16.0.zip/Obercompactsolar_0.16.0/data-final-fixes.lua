require('prototypes.config.solar')
