aai_industry = true

require("prototypes/item/item")
require("prototypes/recipe/recipe")
require("prototypes/entity/resources")
require("prototypes/entity/entity")
require("prototypes/entity/entity-ship-wreck")
require("prototypes/entity/entity-walls")
require("prototypes/entity/entity-burner-lab")
require("prototypes/entity/entity-offshore-pump")
require("prototypes/entity/entity-burner-turbine")
require("prototypes/entity/entity-burner-assembling-machine")
require("prototypes/entity/entity-fuel-processor")
require("prototypes/technology/technology")
