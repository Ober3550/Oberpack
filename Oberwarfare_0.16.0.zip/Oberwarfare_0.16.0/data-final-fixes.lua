require('prototypes.config.bobwarfare')
require('prototypes.technology.technology')