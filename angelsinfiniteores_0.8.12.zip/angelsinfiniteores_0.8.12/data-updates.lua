
-- EXECUTE OVERRIDES
if not angelsmods.refining then
	angelsmods.functions.update_autoplace()
end
