function InfiniteResearchUnitFormula(research,multiplier)
    for index=1,20,1 do
        if data.raw.technology[research..index] then
            if data.raw.technology[research..index].unit.count then
                local previous = data.raw.technology[research..index].unit.count
                data.raw.technology[research..index].unit.count  = previous * multiplier
            elseif data.raw.technology[research..index].unit.count_formula then
                local previous = data.raw.technology[research..index].unit.count_formula
                data.raw.technology[research..index].unit.count_formula = "("..previous..")*"..multiplier
            end
        end
    end
end
function SingleResertFormula(research,multiplier)
        if data.raw.technology[research] then
            if data.raw.technology[research].unit.count then
                local previous = data.raw.technology[research].unit.count
                data.raw.technology[research].unit.count  = previous * multiplier
            elseif data.raw.technology[research].unit.count_formula then
                local previous = data.raw.technology[research].unit.count_formula
                data.raw.technology[research].unit.count_formula = "("..previous..")*"..multiplier
            end
        end
end
--Vanilla

InfiniteResearchUnitFormula("follower-robot-count-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("rocket-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("rocket-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bullet-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bullet-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("shotgun-shell-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("shotgun-shell-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("laser-turret-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("laser-turret-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("cannon-shell-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("cannon-shell-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("gun-turret-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("flamethrower-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("combat-robot-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("artillery-shell-range-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("artillery-shell-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("grenade-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("mining-productivity-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("worker-robots-speed-",settings.startup["inf-tech-mult"].value)

--Modded
if mods["wormmus-inf-tech"] then

InfiniteResearchUnitFormula("worker-robots-storage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("research-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("inserter-capacity-bonus-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bob-sniper-turret-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bob-laser-rifle-speed-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bob-laser-rifle-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("braking-force-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("character-inventory-slots-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("bob-artillery-damage-",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("character-logistic-slots-",settings.startup["inf-tech-mult"].value)

end

if mods["Factorissimo2"] then
InfiniteResearchUnitFormula("factory-architecture-t",settings.startup["inf-tech-mult"].value)
InfiniteResearchUnitFormula("factory-recursion-t",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-connection-type-fluid",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-connection-type-chest",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-connection-type-circuit",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-interior-upgrade-lights",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-interior-upgrade-display",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-preview",settings.startup["inf-tech-mult"].value)
SingleResertFormula("factory-requester-chest",settings.startup["inf-tech-mult"].value)
end