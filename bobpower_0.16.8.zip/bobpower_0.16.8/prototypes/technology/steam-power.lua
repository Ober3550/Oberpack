data:extend(
{
  {
    type = "technology",
    name = "bob-steam-power-1",
    prerequisites =
    {
      "steel-processing",
    },
    icon = "__bobpower__/graphics/icons/steam-power.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "steam-engine-2"
      },
      {
        type = "unlock-recipe",
        recipe = "boiler-2"
      },
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "[steam]-1",
  },

  {
    type = "technology",
    name = "bob-steam-power-2",
    prerequisites =
    {
      "bob-steam-power-1",
    },
    icon = "__bobpower__/graphics/icons/steam-power.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "steam-engine-3"
      },
      {
        type = "unlock-recipe",
        recipe = "boiler-3"
      },
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "[steam]-2",
  },

  {
    type = "technology",
    name = "bob-steam-power-3",
    prerequisites =
    {
      "bob-steam-power-2",
    },
    icon = "__bobpower__/graphics/icons/steam-power.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "steam-engine-4"
      },
      {
        type = "unlock-recipe",
        recipe = "boiler-4"
      },
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
      },
      time = 30
    },
    upgrade = true,
    order = "[steam]-3",
  },

  {
    type = "technology",
    name = "bob-steam-power-4",
    prerequisites =
    {
      "bob-steam-power-3",
    },
    icon = "__bobpower__/graphics/icons/steam-power.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "steam-engine-5"
      },
      {
        type = "unlock-recipe",
        recipe = "boiler-5"
      },
    },
    unit =
    {
      count = 50,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "[steam]-4",
  },
}
)


