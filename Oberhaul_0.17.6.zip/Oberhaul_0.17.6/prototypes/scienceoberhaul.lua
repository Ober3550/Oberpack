--Clear Science Pack Recipes
if mods.bobplates and mods.bobtech then
data.raw.recipe['automation-science-pack'].ingredients = {
    {"iron-gear-wheel",1},
    {"copper-plate",2}
}
data.raw.recipe["logistic-science-pack"].result_count = 2
if mods.boblogistics then
if settings.startup["bobmods-logistics-inserteroverhaul"].value then
data.raw.recipe['logistic-science-pack'].ingredients = {
    {"long-handed-inserter",1},
    {"small-electric-pole",1}
}
data.raw.technology["fast-inserter"].unit.ingredients = {{"automation-science-pack",1}}
data.raw.technology["fast-inserter"].prerequisites = {"electronics","logistics-0"}
data.raw.technology["logistic-science-pack"].prerequisites = {"fast-inserter"}
else
data.raw.recipe['logistic-science-pack'].ingredients = {
    {"fast-inserter",1},
    {"small-electric-pole",1}
}
end
end
bobmods.lib.tech.remove_recipe_unlock("automation-2","logistic-science-pack")
data.raw.recipe['military-science-pack'].ingredients = {
    {"gunmetal-alloy",4},
    {"invar-alloy",3},
    {"grenade",1}
}
data.raw.technology["military-science-pack"].prerequisites = {"military-2","angels-gunmetal-smelting-1","angels-invar-smelting-1"}
data.raw.recipe['chemical-science-pack'].ingredients = {
    {"advanced-circuit",4},
    {"steel-plate",10},
    {"gold-plate",4},
    {"aluminium-plate",4}
}
data.raw.technology["chemical-science-pack"].prerequisites = {"advanced-electronics","angels-gold-smelting-1","angels-aluminium-smelting-1","angels-steel-smelting-1"}

data.raw.recipe["advanced-logistic-science-pack"].ingredients = {
    --{"car", 1},
    {"express-transport-belt", 1},
    {"flying-robot-frame", 1},
    {"brass-chest", 1}
}

data.raw.recipe['production-science-pack'].ingredients = {
    {"bob-pump-4",2},
    {"cobalt-steel-alloy",5},
    {"processing-unit",4},
    {"ruby-5",2},
    {"sapphire-5",2}
}
data.raw.technology["production-science-pack"].prerequisites = {"bob-fluid-handling-4","angels-cobalt-smelting-1","gem-processing-2","advanced-electronics-2"}
data.raw.technology["production-science-pack"].unit.ingredients = {{"automation-science-pack",1},{"logistic-science-pack",1},{"chemical-science-pack",1},{"advanced-logistic-science-pack",1}}
data.raw.recipe["utility-science-pack"].energy_required = 28
data.raw.recipe["utility-science-pack"].result_count = 4
data.raw.recipe['utility-science-pack'].ingredients = {
    {"angels-wire-silver",30},
    --{"tungsten-pipe-to-ground",2},
    --{"electrum-alloy",8},
    --{"advanced-processing-unit",4},
    {"uranium-238",5},
    {"rubber",10},
    {"bob-mining-drill-4",1},
}
data.raw.technology["utility-science-pack"].prerequisites = {"bob-drills-4","rubber","angels-silver-smelting-2","uranium-processing","advanced-research"}
data.raw.technology["utility-science-pack"].unit.ingredients = {{"automation-science-pack",1},{"logistic-science-pack",1},{"chemical-science-pack",1},{"advanced-logistic-science-pack",1},{"production-science-pack",1}}
data.raw.recipe["rocket-control-unit"].ingredients = {
    {"advanced-processing-unit",1},
    {"productivity-module-2",1}
}
if mods.bobtech then
data.raw.recipe["lab-2"].ingredients = {
    {"express-stack-inserter", 2},
    {"turbo-transport-belt",2},
    {"advanced-processing-unit",2},
    {"lab",1}
}
end
end
--Technology
--Make Lazy Bastard Possible
if mods["aai-industry"] then
  data.raw.technology["basic-automation"].unit = {count=1,ingredients={{"automation-science-pack",1}},time=30}
  data.raw.technology["basic-logistics"].unit = {count=1,ingredients={{"automation-science-pack",1}},time=30}
  data.raw.lab["burner-lab"].inputs = {"automation-science-pack"}
end

if mods.bobelectronics then
data.raw.technology['advanced-electronics-3'].unit =
{
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}, 
        {"production-science-pack", 1}
      },
      time = 30,
      count = 100
}
end

--Require Lab Mk2 for High tech and Space science
data.raw.lab["lab"].inputs = {"automation-science-pack","logistic-science-pack","chemical-science-pack","military-science-pack","advanced-logistic-science-pack","production-science-pack","token-bio"}
data.raw.technology["advanced-research"].prerequisites = {"logistics-4","advanced-electronics-3"}
data.raw.technology["advanced-research"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"advanced-logistic-science-pack", 1},
    {"production-science-pack",1}
}
if mods.boblogistics then
if settings.startup["bobmods-logistics-inserteroverhaul"].value then
data.raw.technology["stack-inserter-4"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"advanced-logistic-science-pack", 1},
    {"production-science-pack", 1}
}
bobmods.lib.tech.add_prerequisite("advanced-research","stack-inserter-4")
data.raw.technology["ultimate-inserter"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"advanced-logistic-science-pack", 1},
    {"production-science-pack", 1}
}
data.raw.technology["ultimate-inserter"].prerequisites = {"logistics-4","turbo-inserter"}
end
end
-- --Reorder the dependancies of science packs
-- bobmods.lib.tech.add_recipe_unlock("advanced-electronics-2", "production-science-pack")
-- bobmods.lib.tech.add_recipe_unlock("advanced-electronics-3", "utility-science-pack")
-- bobmods.lib.tech.remove_recipe_unlock("advanced-electronics-2","utility-science-pack")
-- bobmods.lib.tech.remove_recipe_unlock("advanced-material-processing-2","production-science-pack")
-- data.raw.technology["advanced-research"].prerequisites = {"advanced-electronics-2","bob-logistics-4"}
-- bobmods.lib.tech.add_new_science_pack("advanced-research","production-science-pack",1)
-- bobmods.lib.tech.add_new_science_pack("advanced-research","logistic-science-pack",1)
-- data.raw.technology["advanced-electronics-3"].prerequisites = {"advanced-electronics-2","advanced-research"}

if mods.SpaceMod then
bobmods.lib.tech.add_new_science_pack("spaceship-command","military-science-pack",1)
bobmods.lib.tech.add_new_science_pack("ftl-theory-D","military-science-pack",1)
bobmods.lib.tech.add_new_science_pack("ftl-propulsion","military-science-pack",1)
end