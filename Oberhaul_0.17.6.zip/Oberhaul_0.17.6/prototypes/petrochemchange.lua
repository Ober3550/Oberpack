--Only hand craft resin
data:extend({
{
    type = "recipe-category",
    name = "crafting-handonly"
},
{
    type = "recipe",
    name = "ober-resin-wood",
    energy_required = 0.1,
    category = "crafting-handonly",
    enabled = true,
    ingredients =
    {
      {"wood", 1},
    },
    result = "resin"
  },
})
table.insert(data.raw.character.character.crafting_categories, "crafting-handonly")

--Remove smelting resin to rubber
data.raw.recipe["bob-rubber"].hidden = true
data.raw.recipe["bob-resin-wood"].hidden = true