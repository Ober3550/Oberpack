for _, lamp in pairs(data.raw.lamp) do
    lamp.fast_replaceable_group = "lamps"
end