data:extend(
{
  {
    type = "recipe",
    name = "omega-drill",
    enabled = "false",
    ingredients =
    {
      {"steel-plate", 100},
	  {"iron-gear-wheel", 100},
	  {"advanced-circuit", 25},
	  {"electric-engine-unit", 25},
	  {"electric-mining-drill", 25},
	  {"express-transport-belt", 16}
    },
    result = "omega-drill"
  },
 })
 