data:extend(
{
  {
    type = "mining-drill",
    name = "omega-drill",
    icon = "__OmegaDrill__/graphics/icons/omega-drill.png",
	icon_size=32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 25, result = "omega-drill"},
    max_health = 7500,
    resource_categories = {"basic-solid"},
    corpse = "big-remnants",
    collision_box = {{ -7.1, -7.1}, {7.1, 7.1}},
    selection_box = {{ -7.5, -7.5}, {7.5, 7.5}},
    input_fluid_box =
    {
      production_type = "input-output",
      pipe_picture = assembler2pipepictures(),
      pipe_covers = pipecoverspictures(),
      base_area = 1,
      height = 2,
      base_level = -1,
      pipe_connections =
      {
        { position = {-8, 0} },
        { position = {8, 0} },
        { position = {0, 8} },
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/electric-mining-drill.ogg",
        volume = 0.75
      },
      apparent_volume = 1.5,
    },
	animations =
    {
	    
      north =
      { --a little janky but ehhh
	    layers = 
	    {
	      {
            priority = "high",
            filename = "__OmegaDrill__/graphics/omega-drill/anim.png",
            line_length = 3,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
          },
	      {
            priority = "high",
            --filename = "__OmegaDrill__/graphics/omega-drill/pn.png",
            --line_length = 1,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
	        stripes = util.multiplystripes(8,
            {
              {
               filename = "__OmegaDrill__/graphics/omega-drill/pn.png",
               width_in_frames = 1,
               height_in_frames = 1,
              },
            }),
          },
		}
      },
      east =
      { --a little janky but ehhh
	    layers = 
	    {
	      {
            priority = "high",
            filename = "__OmegaDrill__/graphics/omega-drill/anim.png",
            line_length = 3,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
          },
	      {
            priority = "high",
            --filename = "__OmegaDrill__/graphics/omega-drill/pe.png",
            --line_length = 1,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
	        stripes = util.multiplystripes(8,
            {
              {
               filename = "__OmegaDrill__/graphics/omega-drill/pe.png",
               width_in_frames = 1,
               height_in_frames = 1,
              },
            }),
          },
		}
	  },
      south =
      { --a little janky but ehhh
	    layers = 
	    {
	      {
            priority = "high",
            filename = "__OmegaDrill__/graphics/omega-drill/anim.png",
            line_length = 3,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
          },
	      {
            priority = "high",
            --filename = "__OmegaDrill__/graphics/omega-drill/ps.png",
            --line_length = 1,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
	        stripes = util.multiplystripes(8,
            {
              {
               filename = "__OmegaDrill__/graphics/omega-drill/ps.png",
               width_in_frames = 1,
               height_in_frames = 1,
              },
            }),
          },
		}
      },
      west =
      { --a little janky but ehhh
	    layers = 
	    {
	      {
            priority = "high",
            filename = "__OmegaDrill__/graphics/omega-drill/anim.png",
            line_length = 3,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
          },
	      {
            priority = "high",
            --filename = "__OmegaDrill__/graphics/omega-drill/pw.png",
            --line_length = 1,
            width = 600,
            height = 600,
            frame_count = 8,
            animation_speed = 0.25,
            direction_count = 1,
            shift = { 0 , 0 },
	        stripes = util.multiplystripes(8,
            {
              {
               filename = "__OmegaDrill__/graphics/omega-drill/pw.png",
               width_in_frames = 1,
               height_in_frames = 1,
              },
            }),
          },
		}
      },
    },
	
	
		
	  
    input_fluid_patch_sprites =
    {
      north =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/on.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      east =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/oe.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      south =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/os.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      west =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/ow.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      }
    },
    input_fluid_patch_shadow_sprites =
    {
      north =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/osh.png",
        flags = { "shadow" },
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      east =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/osh.png",
        flags = { "shadow" },
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      south =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/osh.png",
        flags = { "shadow" },
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      west =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/osh.png",
        flags = { "shadow" },
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      }
    },
    input_fluid_patch_window_sprites =
    {
      north =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flbg.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      east =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flbg.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      south =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flbg.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      },
      west =
      {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flbg.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
      }
    },
    
    input_fluid_patch_window_flow_sprites =
    {
      {
        north =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flfl.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        east =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flfl.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        south =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flfl.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        west =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flfl.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        }
      },
    },
    input_fluid_patch_window_base_sprites =
    {
      {
        north =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flms.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        east =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flms.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        south =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flms.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        },
        west =
        {
        priority = "high",
        filename = "__OmegaDrill__/graphics/omega-drill/flms.png",
        line_length = 1,
        width = 600,
        height = 600,
        frame_count = 1,
        direction_count = 1,
        shift = { 0 , 0 }
        }
      },
    },
    
	
    
    mining_speed = 37.5, --turn up
    energy_source =
    {
      type = "electric",
      -- will produce this much * energy pollution units per tick
      emissions = 0.15 / 1.5,
      usage_priority = "secondary-input"
    },
    energy_usage = "2250kW",
    mining_power = 3,
    resource_searching_radius = 12.49,
    vector_to_place_result = {0, -7.85},
    module_specification =
    {
      module_slots = 3
    },
    radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
      width = 12,
      height = 12
    },
    monitor_visualization_tint = {r=78, g=173, b=255},
    fast_replaceable_group = "mining-drill",
    circuit_wire_connection_points = circuit_connector_definitions["electric-mining-drill"].points,
    circuit_connector_sprites = circuit_connector_definitions["electric-mining-drill"].sprites,
    circuit_wire_max_distance = default_circuit_wire_max_distance
	
  },
}
)
