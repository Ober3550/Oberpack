data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-enemies-enableartifacts",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-enemies-enablesmallartifacts",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-enemies-enablenewartifacts",
    setting_type = "startup",
    default_value = false,
    per_user = false,
  },

  {
    type = "bool-setting",
    name = "bobmods-enemies-aliensdropartifacts",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
}
)

