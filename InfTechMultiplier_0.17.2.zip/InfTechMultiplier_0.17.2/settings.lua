data:extend({
   {
      type = "double-setting",
      name = "inf-tech-mult",
      setting_type = "startup",
      min_value = 0.01,
      default_value = 0.1,
   },
})