function InfiniteResearchUnitFormula(research,multiplier)
    for index=1,20,1 do
        if data.raw.technology[research..index] then
            if data.raw.technology[research..index].unit.count then
                local previous = data.raw.technology[research..index].unit.count
                data.raw.technology[research..index].unit.count  = math.ceil(previous * multiplier)
            elseif data.raw.technology[research..index].unit.count_formula then
                local previous = data.raw.technology[research..index].unit.count_formula
                data.raw.technology[research..index].unit.count_formula = "("..previous..")*"..multiplier
            end
        end
    end
end
function SingleRevertFormula(research,multiplier)
        if data.raw.technology[research] then
            if data.raw.technology[research].unit.count then
                local previous = data.raw.technology[research].unit.count
                data.raw.technology[research].unit.count  = math.ceil(previous * multiplier)
            elseif data.raw.technology[research].unit.count_formula then
                local previous = data.raw.technology[research].unit.count_formula
                data.raw.technology[research].unit.count_formula = "("..previous..")*"..multiplier
            end
        end
end
local vanilla_tech = {
    "artillery-shell-range-",
    "artillery-shell-speed-",
    "braking-force-",
    "character-logistic-slots-",
    "character-logistic-trash-slots-",
    "energy-weapons-damage-",
    "follower-robot-count-",
    "inserter-capacity-bonus-",
    "laser-turret-speed-",
    "mining-productivity-",
    "physical projectile-damage-",
    "refined-flammables-",
    "research-speed-",
    "stronger-explosives-",
    "weapon-shooting-speed-",
    "worker-robots-speed-",
    "worker-robots-storage-"
}
for tech in pairs(vanilla_tech) do
        InfiniteResearchUnitFormula(tech,settings.startup["inf-tech-mult"].value)
end

--Modded
if mods["wormmus-inf-tech"] then
local wormus_tech = {
    "worker-robots-storage-",
    "research-speed-",
    "inserter-capacity-bonus-",
    "bob-sniper-turret-damage-",
    "bob-laser-rifle-speed-",
    "bob-laser-rifle-damage-",
    "braking-force-",
    "character-inventory-slots-",
    "bob-artillery-damage-",
    "character-logistic-slots-"
    }
    for tech in pairs(wormus_tech) do
        InfiniteResearchUnitFormula(tech,settings.startup["inf-tech-mult"].value)
    end
end

-- if mods["Factorissimo2"] then
-- InfiniteResearchUnitFormula("factory-architecture-t",settings.startup["inf-tech-mult"].value)
-- InfiniteResearchUnitFormula("factory-recursion-t",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-connection-type-fluid",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-connection-type-chest",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-connection-type-circuit",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-interior-upgrade-lights",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-interior-upgrade-display",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-preview",settings.startup["inf-tech-mult"].value)
-- SingleRevertFormula("factory-requester-chest",settings.startup["inf-tech-mult"].value)
-- end

if mods["aai-industry"] then
local aai_industry_tech = {
    "basic-automation",
    "basic-logistics",
    -- "electricity",
    -- "filter-inserters",
    -- "radar",
    -- "basic-fluid-handling",
    -- "steam-power",
    -- "electric-lab",
    "electric-mining"
}
    for tech in pairs(aai_industry_tech) do
        SingleRevertFormula(tech,settings.startup["inf-tech-mult"].value)
    end
end