local basespeed = 1/32
local belts = {"transport-belt","fast-transport-belt","express-transport-belt"}
local splitters = {"splitter","fast-splitter","express-splitter"}
local undergrounds = {"underground-belt","fast-underground-belt","express-underground-belt"}
local loaders = {"deadlock-loader-1","deadlock-loader-2","deadlock-loader-3","deadlock-loader-4","deadlock-loader-5"}

if mods.boblogistics then
    table.insert(belts,"turbo-transport-belt")
    table.insert(splitters,"turbo-splitter")
    table.insert(undergrounds,"turbo-underground-belt")
    table.insert(belts,"ultimate-transport-belt")
    table.insert(splitters,"ultimate-splitter")
    table.insert(undergrounds,"ultimate-underground-belt")
    if settings.startup["bobmods-logistics-beltoverhaul"].value then
        data.raw["transport-belt"]["basic-transport-belt"].speed = 0.5*basespeed
		data.raw["splitter"]["basic-splitter"].speed = 0.5*basespeed
		data.raw["underground-belt"]["basic-underground-belt"].speed = 0.5*basespeed
		data.raw["underground-belt"]["basic-underground-belt"].max_distance = 5
		if mods.DeadlockLoaders then
			data.raw["loader"]["deadlock-loader-0"].speed = 0.5*basespeed
		end
    end
end

for i=1,5 do
	data.raw["transport-belt"][belts[i]].speed = basespeed*(2^(i-1))
	data.raw["splitter"][splitters[i]].speed = basespeed*(2^(i-1))
	data.raw["underground-belt"][undergrounds[i]].speed = basespeed*(2^(i-1))
	data.raw["underground-belt"][undergrounds[i]].max_distance = 5+(6*(i-1))
	if mods.DeadlockLoaders then
		data.raw["loader"][loaders[i]].speed = basespeed*(2^(i-1))
	end
end

