if mods.angelsrefining then
if mods.seablock then
else
-- Washing plant sulfur byproduct

local washing_fluid_box = {
 
production_type = 'output',
  
pipe_covers = pipecoverspictures(),
  
base_level = 1,
  pipe_connections = {{ position = {-3, 0} }}

}

table.insert(data.raw['assembling-machine']['washing-plant'].fluid_boxes, washing_fluid_box)

table.insert(data.raw['assembling-machine']['washing-plant-2'].fluid_boxes, washing_fluid_box)

table.insert(data.raw.recipe['washing-1'].results,
  {type = "fluid", name = "gas-hydrogen-sulfide", amount = 20}
)
end
end
if mods.angelssmelting then
--Cooling Tower
data.raw.recipe["coolant-used-filtration-1"].ingredients =
{
    {type="fluid", name="liquid-coolant-used", amount=100, maximum_temperature = 200},
    {type="item", name="filter-coal", amount=1},
}
data.raw.recipe["coolant-used-filtration-1"].results =
{	  
    {type="fluid", name="liquid-coolant", amount=99, temperature = 25},
    {type="item", name="filter-frame", amount=1},
}
data.raw.recipe["coolant-used-filtration-2"].ingredients =
{
    {type="fluid", name="liquid-coolant-used", amount=100, maximum_temperature = 200},
    {type="item", name="filter-ceramic", amount=1},
}
data.raw.recipe["coolant-used-filtration-2"].results =
{
    {type="fluid", name="liquid-coolant", amount=100, temperature = 25},
    {type="item", name="filter-ceramic-used", amount=1},
}
data.raw.recipe["coolant-cool-200"].hidden = true
data.raw.recipe["coolant-cool-100"].hidden = true

data.raw.technology["angels-coolant-1"].effects =
{
    {
        type = "unlock-recipe",
        recipe = "cooling-tower"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-used-filtration-1"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-300"
    },
    {
        type = "unlock-recipe",
        recipe = "coolant-cool-steam"
    }
}
end