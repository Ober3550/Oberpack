data:extend(
{
  {
    type = "item-subgroup",
    name = "angels-warehouses",
	group = "logistics",
	order = "zd",
  },
  }
  )