-- Reload recipes and technologies
for i, player in ipairs(game.players) do
  player.force.reset_recipes()
  player.force.reset_technologies()
end

for index, force in pairs(game.forces) do
  -- Generate technology and recipe tables
  local tech = force.technologies
  local recipes = force.recipes

  -- Kovarex recipe deprecated
  if recipes["kovarex-enrichment-process"] then
    recipes["kovarex-enrichment-process"].enabled = false
  end

  -- Unlock researched recipes
  if tech["nuclear-fuel-reprocessing"] and tech["nuclear-fuel-reprocessing"].researched then
    if recipes["breeder-fuel-cell"] then
      recipes["breeder-fuel-cell"].enabled = true
    end
    if recipes["breeder-fuel-reprocessing"] then
      recipes["breeder-fuel-reprocessing"].enabled = true
    end
  end
  if tech["kovarex-enrichment-process"] and tech["kovarex-enrichment-process"].researched then
    if recipes["mox-fuel-cell"] then
      recipes["mox-fuel-cell"].enabled = true
    end
  end
  
  -- Moved nuclear fuel to silo tech, unlock it
  if tech["rocket-silo"] and tech["rocket-silo"].researched then
    recipes["nuclear-fuel"].enabled = true
  end
end