table.insert(
  data.raw["recipe"]["nuclear-fuel-reprocessing"].results,
  {name = "plutonium", probability = 0.25, amount = 1})

data.raw["recipe"]["atomic-bomb"].ingredients = {
  {"processing-unit", 20},
  {"explosives", 10},
  {"plutonium", 5}
}
  
data:extend({
  {
    type = "recipe",
    name = "mox-fuel-cell",
    icon = "__Nuclear Fuel__/graphics/icons/mox-fuel-cell.png",
    icon_size = 32,
    subgroup = "intermediate-product",
    order = "r[uranium-processing]-a[uranium-fuel-cell]y",
    energy_required = 10,
    enabled = false,
    ingredients =
    {
      {"iron-plate", 10},
      {"plutonium", 1},
      {"uranium-238", 9}
    },
    result = "uranium-fuel-cell",
    result_count = 10
  },
  {
    type = "recipe",
    name = "breeder-fuel-cell",
    energy_required = 10,
    enabled = false,
    ingredients =
    {
      {"iron-plate", 10},
      {"plutonium", 1},
      {"uranium-238", 19}
    },
    result = "breeder-fuel-cell",
    result_count = 10
  },
   {
    type = "recipe",
    name = "breeder-fuel-reprocessing",
    energy_required = 50,
    enabled = false,
    category = "centrifuging",
    ingredients = {{"used-up-breeder-fuel-cell", 5}},
    icon = "__Nuclear Fuel__/graphics/icons/breeder-fuel-reprocessing.png",
    icon_size = 32,
    subgroup = "intermediate-product",
    order = "r[uranium-processing]-b[nuclear-fuel-reprocessing]z",
    allow_decomposition = false,
    main_product = "",
    results =
    {
      {
        name = "plutonium",
        amount = 2
      },
      {
        name = "uranium-235",
        probability = 0.5,
        amount = 1
      }
    }
  }
})