data.raw["technology"]["kovarex-enrichment-process"].icon = "__Nuclear Fuel__/graphics/technology/plutonium-kovarex.png"
-- data.raw["technology"]["kovarex-enrichment-process"].icon_size = 128
data.raw["technology"]["kovarex-enrichment-process"].effects = {
  {
    type = "unlock-recipe",
    recipe = "mox-fuel-cell"
  } 
}

table.insert(
  data.raw["technology"]["nuclear-fuel-reprocessing"].effects,
  {type = "unlock-recipe",recipe = "breeder-fuel-cell"})
table.insert(
  data.raw["technology"]["nuclear-fuel-reprocessing"].effects,
  {type = "unlock-recipe",recipe = "breeder-fuel-reprocessing"})

table.insert(
  data.raw["technology"]["rocket-silo"].effects,
  {type = "unlock-recipe",recipe = "nuclear-fuel"})