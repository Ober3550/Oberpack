--[[Angel Ores names
angels-ore1  Saphirite
angels-ore2  Jivolite
angels-ore3  Stiratite
angels-ore4  Crotinnium
angels-ore5  Rubyte
angels-ore6  Bobmonium
angels-fissure 
angels-natural-gas
crude-oil

iron-ore
copper-ore
coal
stone
uranium

tin-ore
lead-ore

quartz
bauxite-ore  Aluminium
nickel-ore
zinc-ore

gold-ore
silver-ore
rutile-ore   Titanium
cobalt-ore

gem-ore
tungsten-ore

--Disable these
ground-water
lithia-water
thorium-ore  
--]]
--[[
data.raw['rso-region-size'].default_value = 9
data.raw['rso-resource-chance'].default_value = 0.7
data.raw['rso-global-richness-mult'].default_value = 1.2
data.raw['rso-global-size-mult'].default_value = 1.2
data.raw['rso-multi-resource-active'].default_value = false
data.raw['rso-distance-exponent'].default_value = 1.3
data.raw['rso-size-exponent'].default_value = 0.4
data.raw['rso-fluid-distance-exponent'].default_value = 0.9
--]]