if mods.bobwarfare then
data.raw.technology["bob-ap-bullets"].enabled = false
data.raw.technology["bob-electric-bullets"].enabled = false
data.raw.technology["bob-he-bullets"].enabled = false
data.raw.technology["bob-flame-bullets"].enabled = false
data.raw.technology["bob-acid-bullets"].enabled = false
data.raw.technology["bob-poison-bullets"].enabled = false
--data.raw.technology["bob-shotgun-shells"].enabled = false
data.raw.technology["bob-shotgun-ap-shells"].enabled = false
data.raw.technology["bob-shotgun-electric-shells"].enabled = false
data.raw.technology["bob-shotgun-explosive-shells"].enabled = false
data.raw.technology["bob-shotgun-flame-shells"].enabled = false
data.raw.technology["bob-shotgun-acid-shells"].enabled = false
data.raw.technology["bob-shotgun-poison-shells"].enabled = false
data.raw.technology["bob-rocket"].enabled = false
data.raw.technology["bob-acid-rocket"].enabled = false
data.raw.technology["bob-flame-rocket"].enabled = false
data.raw.technology["bob-poison-rocket"].enabled = false
data.raw.technology["bob-piercing-rocket"].enabled = false
data.raw.technology["bob-electric-rocket"].enabled = false
data.raw.technology["bob-explosive-rocket"].enabled = false
bobmods.lib.recipe.add_ingredient("bob-power-armor-mk4",{"heavy-armor-2",1})
bobmods.lib.recipe.add_ingredient("bob-power-armor-mk5",{"heavy-armor-3",1})
data.raw.recipe["solar-panel-equipment-4"].ingredients = {
      {"solar-panel-equipment-3", 1},
      {"steel-plate", 2},
      {"advanced-processing-unit", 5},
      {"copper-cable", 5},
}

--Changing Bullet Complexity Back
data.raw.recipe["sulfuric-nitric-acid"].hidden = true
data.raw.recipe["gas-glycerol"].ingredients = {{type="fluid", name="light-oil", amount=100}}
data:extend(
{ 
  {
    type = "recipe",
    name = "nitroglycerin",
    category = "chemistry",
    enabled = "false",
    energy_required = 1.5,
    ingredients =
    {
      {type="fluid", name="glycerol", amount=10},
      {type="fluid", name="sulfuric-acid", amount=30},
    },
    results=
    {
      {type="fluid", name="nitroglycerin", amount=10},
    },
    subgroup = "fluid",
    icon = "__bobwarfare__/graphics/icons/nitroglycerin.png",
    icon_size = 32,
    order = "b[fluid-chemistry]-b[nitroglycerin]"
  },
})
--Lowering Complexity Increasing Requirement
data.raw.recipe["bullet-casing"].hidden = true
data.raw.recipe["magazine"].hidden = true
data.raw.recipe["bullet-projectile"].hidden = true
data.raw.recipe["bullet"].hidden = true
data.raw.recipe["uranium-bullet-projectile"].hidden = true
data.raw.recipe["uranium-bullet"].hidden = true
--data.raw.recipe["shot"].hidden = true
data.raw.recipe["shotgun-shell-casing"].hidden = true
data.raw.recipe["rocket-engine"].hidden = true

data.raw.recipe["bullet-magazine"].ingredients = {
    {"piercing-rounds-magazine",1},
    {"steel-plate",3},
    {"lead-plate",5},
    {"gunmetal-alloy",2},
    {"cordite",3}
}
data.raw.recipe["uranium-rounds-magazine"].ingredients = {
    {"bullet-magazine",1},
    {"uranium-238",2},
    {"cordite",3},
    {"titanium-bearing-ball",4}
}
data.raw.recipe["better-shotgun-shell"].ingredients = {
    {"piercing-shotgun-shell",1},
    {"steel-plate",3},
    {"lead-plate",5},
    {"gunmetal-alloy",2},
    {"cordite",3}
}
data.raw.recipe["shotgun-uranium-shell"].ingredients = {
    {"better-shotgun-shell",1},
    {"uranium-238",2},
    {"cordite",3},
    {"titanium-bearing-ball",4}
}
data.raw.technology["bob-bullets"].effects = {{type = "unlock-recipe", recipe = "bullet-magazine"}}
data.raw.technology["bob-shotgun-shells"].effects = {
      {
        type = "unlock-recipe",
        recipe = "shot"
      },
      {
        type = "unlock-recipe",
        recipe = "better-shotgun-shell"
      }}
data.raw.technology["uranium-ammo"].effects = {
      {
	type = "unlock-recipe",
	recipe = "uranium-rounds-magazine"
      },
      {
	type = "unlock-recipe",
	recipe = "shotgun-uranium-shell"
      }
}
data.raw.technology["uranium-ammo"].prerequisites = {"ober-uranium-processing","bob-bullets","bob-shotgun-shells","titanium-processing"}
data.raw.technology["uranium-ammo"].unit = 
{
      count = 200,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
	  {"military-science-pack",1}
	  },
      time = 30
}
data.raw.technology["bob-power-armor-3"].unit.ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1},
          {"military-science-pack", 1},
          {"production-science-pack", 1}}

if mods.ShinyBobGFX then
data.raw["solar-panel-equipment"]["solar-panel-equipment"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-1.png"
data.raw["solar-panel-equipment"]["solar-panel-equipment-2"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-2.png"
data.raw["solar-panel-equipment"]["solar-panel-equipment-3"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-3.png"
data.raw["solar-panel-equipment"]["solar-panel-equipment-4"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-4.png"

--data.raw.technology["solar-panel-equipment"].icon_size = 128
data.raw.technology["solar-panel-equipment-2"].icon_size = 128
data.raw.technology["solar-panel-equipment-3"].icon_size = 128
data.raw.technology["solar-panel-equipment-4"].icon_size = 128

--data.raw.technology["solar-panel-equipment"].icon = "__ScienceOberhaul__/graphics/solar-panel-equipment-1.png"
data.raw.technology["solar-panel-equipment-2"].icon = "__ScienceOberhaul__/graphics/solar-panel-equipment-2.png"
data.raw.technology["solar-panel-equipment-3"].icon = "__ScienceOberhaul__/graphics/solar-panel-equipment-3.png"
data.raw.technology["solar-panel-equipment-4"].icon = "__ScienceOberhaul__/graphics/solar-panel-equipment-4.png"
end

--data.raw.recipe["belt-immunity-equipment"].ingredients = {{"turbo-transport-belt",20},{"exoskeleton-equipment",2}}
data.raw["belt-immunity-equipment"]["belt-immunity-equipment"].shape = {width=2,height=2,type="full"}

data:extend({
  {
    type = "recipe",
    name = "ober-portable-solar",
    enabled = "false",
    energy_required = 10,
    ingredients = 
    {{"solar-panel-equipment-4",16}},
    result = "fusion-reactor-equipment",   
  },
  {
    type = "recipe",
    name = "ober-belt-immunity-equipment",
    enabled = "false",
    energy_required = 10,
    ingredients = 
    {{"turbo-transport-belt",20},{"exoskeleton-equipment",2}},
    result = "belt-immunity-equipment",   
  },
})
bobmods.lib.tech.add_recipe_unlock("fusion-reactor-equipment", "ober-portable-solar")
bobmods.lib.tech.add_recipe_unlock("bob-logistics-4", "ober-belt-immunity-equipment")
end