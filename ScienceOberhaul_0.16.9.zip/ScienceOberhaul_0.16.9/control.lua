script.on_init(function()
game.difficulty_settings.technology_price_multiplier=10
end)