data:extend(
{
  {
    type = "item",
    name = "bob-robot-tank",
    icon = "__base__/graphics/icons/tank.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "bob-combat-robots",
    order = "b[personal-transport]-b[tank]",
    place_result = "bob-robot-tank",
    stack_size = 10
  },
}
)

