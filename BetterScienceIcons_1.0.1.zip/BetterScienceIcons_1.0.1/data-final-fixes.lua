if mods["pycoalprocessing"] then
    require("prototypes.better-icons")
end