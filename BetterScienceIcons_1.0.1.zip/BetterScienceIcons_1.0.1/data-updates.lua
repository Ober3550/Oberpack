-- This is contained in data-updates to allow other mods to overwrite these changes in data-final-fixes if necessary
require("prototypes.better-icons")