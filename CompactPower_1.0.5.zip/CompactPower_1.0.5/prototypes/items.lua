function cp_item_factory(name, tier, sort_1)
  return {
      type = "item",
      icon_size = 32,
      name = tiered_name(name, tier),
      icon = tiered_icon(name, tier),
      flags = {"goes-to-quickbar"},
      subgroup = "energy",
      order = sort_1 .. "[" .. tiered_name(name, tier) .. "]-a[" .. tiered_name(name, tier) .. "]",
      place_result = tiered_name(name, tier),
      stack_size = 50
  }
end

data:extend({
  cp_item_factory("solar-panel", 2, "d"),
  cp_item_factory("solar-panel", 3, "d"),
  cp_item_factory("solar-panel", 4, "d"),
  cp_item_factory("solar-panel", 5, "d"),

  cp_item_factory("accumulator", 2, "e"),
  cp_item_factory("accumulator", 3, "e"),
  cp_item_factory("accumulator", 4, "e"),
  cp_item_factory("accumulator", 5, "e")
})
