function cp_recipe_factory(name, tier, extra_ingredient)
  if ((tier < 2) or (tier > 5)) then
    error("Invalid tier “"..tier.."” passed to cp_recipe_factory()")
  else
    return {
        type = "recipe",
        name = tiered_name(name, tier),
        energy_required = 10*tier,
        enabled = "false",
        ingredients = {
            {tiered_name(name, tier - 1), tier_multiplier},
            {"copper-cable", tier_multiplier },
            extra_ingredient
        },
        result = tiered_name(name, tier)
    }
  end
end

data:extend({
  cp_recipe_factory("solar-panel", 2, {"electronic-circuit", tier_multiplier + 1}),
  cp_recipe_factory("solar-panel", 3, {"advanced-circuit",   tier_multiplier + 1}),
  cp_recipe_factory("solar-panel", 4, {"processing-unit",    tier_multiplier + 1}),
  cp_recipe_factory("solar-panel", 5, {"space-science-pack", tier_multiplier * 10}),

  cp_recipe_factory("accumulator", 2, {"electronic-circuit", tier_multiplier + 1}),
  cp_recipe_factory("accumulator", 3, {"advanced-circuit",   tier_multiplier + 1}),
  cp_recipe_factory("accumulator", 4, {"processing-unit",    tier_multiplier + 1}),
  cp_recipe_factory("accumulator", 5, {"space-science-pack", tier_multiplier * 10})
})
