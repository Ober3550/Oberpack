mod_name = "CompactPower"
mod_prefix = "cp"

tier_multiplier = 4

function mk2color(tier)
  return "mk"..tier
end

function tier_up_value(val, tier)
  return val * math.pow(tier_multiplier, tier) / tier_multiplier
end

function tiered_name(name, tier)
  if tier == 1 then
    return name
  else
    return mod_prefix .. "-" .. name .. "-mk"..tier
  end
end

function tiered_icon(name, tier)
  return "__" .. mod_name .. "__/graphics/icons/" .. name .. "/" .. name .. "-" .. mk2color(tier) .. ".png"
end

function tiered_entity_icon(name, tier)
  return "__" .. mod_name .. "__/graphics/entity/" .. name .. "/" .. name .. "-" .. mk2color(tier) .. ".png"
end

function tiered_accu_animation(name, anim, tier)
  return "__" .. mod_name .. "__/graphics/entity/" .. name .. "/" .. anim .. "-" .. mk2color(tier) .. ".png"
end

require("prototypes.entities")
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.technologies")
