data:extend({
  {
   type = "int-setting",
   name = "cp-scale",
   setting_type = "runtime-global",
   default_value = 4,
   minimum_value = 2,
   maximum_value = 10,
   order = "a",
  }
})
