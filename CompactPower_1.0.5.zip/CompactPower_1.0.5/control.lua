tier_multiplier = settings.global["cp-scale"].value
