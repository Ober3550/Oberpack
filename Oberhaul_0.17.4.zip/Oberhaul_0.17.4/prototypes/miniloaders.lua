if mods.miniloader then
data.raw.technology["express-miniloader"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"military-science-pack", 1},
    {"advanced-logistic-science-pack", 1}
}
end
if mods.boblogistics then
data.raw.technology["logistics-4"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"military-science-pack", 1},
    {"advanced-logistic-science-pack", 1},
    {"production-science-pack", 1}
}
end