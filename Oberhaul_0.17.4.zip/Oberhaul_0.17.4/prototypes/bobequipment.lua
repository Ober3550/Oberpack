if mods.bobequipment then
data.raw.recipe["solar-panel-equipment-4"].ingredients = {
      {"solar-panel-equipment-3", 1},
      {"steel-plate", 2},
      {"advanced-processing-unit", 5},
      {"copper-cable", 5},
}

data:extend({
  {
    type = "recipe",
    name = "ober-portable-solar",
    enabled = "false",
    energy_required = 10,
    ingredients = 
    {{"solar-panel-equipment-4",16}},
    result = "fusion-reactor-equipment",   
  }
})
bobmods.lib.tech.add_recipe_unlock("fusion-reactor-equipment", "ober-portable-solar")
bobmods.lib.recipe.remove_ingredient("power-armor-mk2","low-density-structure")
if mods.ShinyBobGFX then
-- data.raw["solar-panel-equipment"]["solar-panel-equipment"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-1.png"
-- data.raw["solar-panel-equipment"]["solar-panel-equipment-2"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-2.png"
-- data.raw["solar-panel-equipment"]["solar-panel-equipment-3"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-3.png"
-- data.raw["solar-panel-equipment"]["solar-panel-equipment-4"].sprite.filename = "__ShinyBobGFX__/graphics/icons/solar-panel-equipment-4.png"

-- data.raw.technology["solar-panel-equipment"].icon_size = 128
-- data.raw.technology["solar-panel-equipment-2"].icon_size = 128
-- data.raw.technology["solar-panel-equipment-3"].icon_size = 128
-- data.raw.technology["solar-panel-equipment-4"].icon_size = 128

-- data.raw.technology["solar-panel-equipment"].icon = "__Oberhaul__/graphics/solar-panel-equipment-1.png"
-- data.raw.technology["solar-panel-equipment-2"].icon = "__Oberhaul__/graphics/solar-panel-equipment-2.png"
-- data.raw.technology["solar-panel-equipment-3"].icon = "__Oberhaul__/graphics/solar-panel-equipment-3.png"
-- data.raw.technology["solar-panel-equipment-4"].icon = "__Oberhaul__/graphics/solar-panel-equipment-4.png"
end
end