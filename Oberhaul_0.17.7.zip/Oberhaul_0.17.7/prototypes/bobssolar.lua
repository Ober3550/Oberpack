bobmods.lib.recipe.add_ingredient("solar-panel-small-2", {"solar-panel-small", 3})
bobmods.lib.recipe.add_ingredient("solar-panel-2", {"solar-panel", 3})
bobmods.lib.recipe.add_ingredient("solar-panel-large-2", {"solar-panel-large", 3})

bobmods.lib.recipe.replace_ingredient("solar-panel-small-2", "advanced-circuit","electronic-circuit")
bobmods.lib.recipe.replace_ingredient("solar-panel-2", "advanced-circuit","electronic-circuit")
bobmods.lib.recipe.replace_ingredient("solar-panel-large-2", "advanced-circuit","electronic-circuit")

data.raw["solar-panel"]["solar-panel-small-2"].production = "106.68kW"
data.raw["solar-panel"]["solar-panel-2"].production = "240kW"
data.raw["solar-panel"]["solar-panel-large-2"].production = "426.72kW"

bobmods.lib.recipe.add_ingredient("solar-panel-small-3", {"solar-panel-small-2", 3})
bobmods.lib.recipe.add_ingredient("solar-panel-3", {"solar-panel-2", 3})
bobmods.lib.recipe.add_ingredient("solar-panel-large-3", {"solar-panel-large-2", 3})

bobmods.lib.recipe.replace_ingredient("solar-panel-small-3", "processing-unit","advanced-circuit")
bobmods.lib.recipe.replace_ingredient("solar-panel-3", "processing-unit","advanced-circuit")
bobmods.lib.recipe.replace_ingredient("solar-panel-large-3", "processing-unit","advanced-circuit")

data.raw["solar-panel"]["solar-panel-small-3"].production = "426.72kW"
data.raw["solar-panel"]["solar-panel-3"].production = "960kW"
data.raw["solar-panel"]["solar-panel-large-3"].production = "1706.88kW"

bobmods.lib.recipe.add_ingredient("large-accumulator-2", {"large-accumulator", 3})
bobmods.lib.recipe.add_ingredient("fast-accumulator-2", {"fast-accumulator", 3})
bobmods.lib.recipe.add_ingredient("slow-accumulator-2", {"slow-accumulator", 3})

bobmods.lib.recipe.replace_ingredient("large-accumulator-2", "advanced-circuit","electronic-circuit")
bobmods.lib.recipe.replace_ingredient("fast-accumulator-2", "advanced-circuit","electronic-circuit")
bobmods.lib.recipe.replace_ingredient("slow-accumulator-2", "advanced-circuit","electronic-circuit")

data.raw["accumulator"]["large-accumulator-2"].energy_source.buffer_capacity = "40MJ"
data.raw["accumulator"]["large-accumulator-2"].energy_source.input_flow_limit = "240kW"
data.raw["accumulator"]["large-accumulator-2"].energy_source.output_flow_limit = "240kW"

data.raw["accumulator"]["fast-accumulator-2"].energy_source.buffer_capacity = "16MJ"
data.raw["accumulator"]["fast-accumulator-2"].energy_source.input_flow_limit = "960kW"
data.raw["accumulator"]["fast-accumulator-2"].energy_source.output_flow_limit = "3840kW"

data.raw["accumulator"]["slow-accumulator-2"].energy_source.buffer_capacity = "16MJ"
data.raw["accumulator"]["slow-accumulator-2"].energy_source.input_flow_limit = "960kW"
data.raw["accumulator"]["slow-accumulator-2"].energy_source.output_flow_limit = "120kW"

bobmods.lib.recipe.add_ingredient("large-accumulator-3", {"large-accumulator-2", 3})
bobmods.lib.recipe.add_ingredient("fast-accumulator-3", {"fast-accumulator-2", 3})
bobmods.lib.recipe.add_ingredient("slow-accumulator-3", {"slow-accumulator-2", 3})

bobmods.lib.recipe.replace_ingredient("large-accumulator-3", "processing-unit","advanced-circuit")
bobmods.lib.recipe.replace_ingredient("fast-accumulator-3", "processing-unit","advanced-circuit")
bobmods.lib.recipe.replace_ingredient("slow-accumulator-3", "processing-unit","advanced-circuit")

data.raw["accumulator"]["large-accumulator-3"].energy_source.buffer_capacity = "160MJ"
data.raw["accumulator"]["large-accumulator-3"].energy_source.input_flow_limit = "960kW"
data.raw["accumulator"]["large-accumulator-3"].energy_source.output_flow_limit = "960kW"

data.raw["accumulator"]["fast-accumulator-3"].energy_source.buffer_capacity = "64MJ"
data.raw["accumulator"]["fast-accumulator-3"].energy_source.input_flow_limit = "3840kW"
data.raw["accumulator"]["fast-accumulator-3"].energy_source.output_flow_limit = "15360kW"

data.raw["accumulator"]["slow-accumulator-3"].energy_source.buffer_capacity = "64MJ"
data.raw["accumulator"]["slow-accumulator-3"].energy_source.input_flow_limit = "3840kW"
data.raw["accumulator"]["slow-accumulator-3"].energy_source.output_flow_limit = "480kW"

--Add a mk4 solar and accumulator so my save can work
data:extend(
{
  {
    type = "item",
    name = "large-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    
    subgroup = "bob-energy-accumulator",
    order = "e[accumulator]-a[accumulator]-a-4",
    place_result = "large-accumulator-4",
    stack_size = 50
  },
  {
    type = "item",
    name = "fast-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    
    subgroup = "bob-energy-accumulator",
    order = "e[accumulator]-a[accumulator]-a-4",
    place_result = "fast-accumulator-4",
    stack_size = 50
  },
  {
    type = "item",
    name = "slow-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    
    subgroup = "bob-energy-accumulator",
    order = "e[accumulator]-a[accumulator]-a-4",
    place_result = "slow-accumulator-4",
    stack_size = 50
  },
  {
    type = "item",
    name = "solar-panel-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    
    subgroup = "bob-energy-solar-panel",
    order = "d[solar-panel]-a[solar-panel-4-a]",
    place_result = "solar-panel-4",
    stack_size = 50
  },
  {
    type = "item",
    name = "solar-panel-small-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    
    subgroup = "bob-energy-solar-panel",
    order = "d[solar-panel]-a[solar-panel-4-a]",
    place_result = "solar-panel-small-4",
    stack_size = 50
  },
  {
    type = "item",
    name = "solar-panel-large-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    
    subgroup = "bob-energy-solar-panel",
    order = "d[solar-panel]-a[solar-panel-4-a]",
    place_result = "solar-panel-large-4",
    stack_size = 50
  },
  {
    type = "recipe",
    name = "large-accumulator-4",
    energy_required = 10,
    enabled = "false",
    ingredients =
    {
      {"large-accumulator-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "large-accumulator-4"
  },
  {
    type = "recipe",
    name = "fast-accumulator-4",
    energy_required = 10,
    enabled = "false",
    ingredients =
    {
      {"fast-accumulator-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "fast-accumulator-4"
  },
  {
    type = "recipe",
    name = "slow-accumulator-4",
    energy_required = 10,
    enabled = "false",
    ingredients =
    {
      {"slow-accumulator-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "slow-accumulator-4"
  },
  {
    type = "recipe",
    name = "solar-panel-small-4",
    energy_required = 4.5,
    enabled = "false",
    ingredients =
    {
      {"solar-panel-small-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "solar-panel-small-4"
  },
  {
    type = "recipe",
    name = "solar-panel-4",
    energy_required = 10,
    enabled = "false",
    ingredients =
    {
      {"solar-panel-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "solar-panel-4"
  },
  {
    type = "recipe",
    name = "solar-panel-large-4",
    energy_required = 18,
    enabled = "false",
    ingredients =
    {
      {"solar-panel-large-3", 4},
      {"processing-unit",4},
      {"tungsten-plate",8}
    },
    result = "solar-panel-large-4"
  },
  {
    type = "technology",
    name = "ober-electric-energy-accumulators-4",
    icon = "__base__/graphics/technology/electric-energy-acumulators.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "large-accumulator-4"
      },
      {
        type = "unlock-recipe",
        recipe = "fast-accumulator-4"
      },
      {
        type = "unlock-recipe",
        recipe = "slow-accumulator-4"
      }
    },
    prerequisites =
    {
       "bob-electric-energy-accumulators-3"
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"advanced-logistic-science-pack", 1},
        {"production-science-pack", 1},
      },
      time = 30
    },
    order = "c-e-a-4",
  },
  {
    type = "technology",
    name = "ober-solar-energy-4",
    icon = "__base__/graphics/technology/solar-energy.png",
    icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "solar-panel-4"
      },
      {
        type = "unlock-recipe",
        recipe = "solar-panel-small-4"
      },
      {
        type = "unlock-recipe",
        recipe = "solar-panel-large-4"
      }
    },
    prerequisites =
    {
        "bob-solar-energy-3"
    },
    unit =
    {
      count = 500,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"advanced-logistic-science-pack", 1},
        {"production-science-pack", 1},
      },
      time = 30
    },
    order = "c-e-a-4",
  },
  {
    type = "accumulator",
    name = "large-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "large-accumulator-4"},
    max_health = 150,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
    energy_source =
    {
      type = "electric",
      buffer_capacity = "640MJ",
      usage_priority = "tertiary",
      input_flow_limit = "3840kW",
      output_flow_limit = "3840kW"
    },
    picture = accumulator_picture(),
    charge_animation = accumulator_charge(),
    charge_cooldown = 30,
    charge_light = {intensity = 0.3, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    discharge_animation = accumulator_discharge(),
    discharge_cooldown = 60,
    discharge_light = {intensity = 0.7, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 1
      },
      idle_sound = {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 5
    },
    fast_replaceable_group = "accumulator",
    circuit_wire_connection_point = circuit_connector_definitions["accumulator"].points,
    circuit_connector_sprites = circuit_connector_definitions["accumulator"].sprites,
    circuit_wire_max_distance = 7.5,
    default_output_signal = {type = "virtual", name = "signal-A"}
  },

  {
    type = "accumulator",
    name = "fast-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "fast-accumulator-4"},
    max_health = 150,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
    energy_source =
    {
      type = "electric",
      buffer_capacity = "256MJ",
      usage_priority = "tertiary",
      input_flow_limit = "15360kW",
      output_flow_limit = "1920kW"
    },
    picture = accumulator_picture(),
    charge_animation = accumulator_charge(),
    charge_cooldown = 30,
    charge_light = {intensity = 0.3, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    discharge_animation = accumulator_discharge(),
    discharge_cooldown = 60,
    discharge_light = {intensity = 0.7, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 1
      },
      idle_sound = {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 5
    },
    fast_replaceable_group = "accumulator",
    circuit_wire_connection_point = circuit_connector_definitions["accumulator"].points,
    circuit_connector_sprites = circuit_connector_definitions["accumulator"].sprites,
    circuit_wire_max_distance = 7.5,
    default_output_signal = {type = "virtual", name = "signal-A"}
  },

  {
    type = "accumulator",
    name = "slow-accumulator-4",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "slow-accumulator-4"},
    max_health = 150,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1, -1}, {1, 1}},
    energy_source =
    {
      type = "electric",
      buffer_capacity = "256MJ",
      usage_priority = "tertiary",
      input_flow_limit = "15360kW",
      output_flow_limit = "1920kW"
    },
    picture = accumulator_picture(),
    charge_animation = accumulator_charge(),
    charge_cooldown = 30,
    charge_light = {intensity = 0.3, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    discharge_animation = accumulator_discharge(),
    discharge_cooldown = 60,
    discharge_light = {intensity = 0.7, size = 7, color = {r = 1.0, g = 1.0, b = 1.0}},
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/accumulator-working.ogg",
        volume = 1
      },
      idle_sound = {
        filename = "__base__/sound/accumulator-idle.ogg",
        volume = 0.4
      },
      max_sounds_per_type = 5
    },
    fast_replaceable_group = "accumulator",
    circuit_wire_connection_point = circuit_connector_definitions["accumulator"].points,
    circuit_connector_sprites = circuit_connector_definitions["accumulator"].sprites,
    circuit_wire_max_distance = 7.5,
    default_output_signal = {type = "virtual", name = "signal-A"}
  },
  {
    type = "solar-panel",
    name = "solar-panel-small-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "solar-panel-small-4"},
    max_health = 200,
    corpse = "medium-remnants",
    collision_box = {{-0.9, -0.9}, {0.9, 0.9}},
    selection_box = {{-1.0, -1.0}, {1.0, 1.0}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__bobpower__/graphics/solar-panel/solar-panel-s2.png",
      priority = "high",
      width = 72,
      height = 69
    },
    production = "1706.88kW",
    fast_replaceable_group = "solar-panel",
  },
  {
    type = "solar-panel",
    name = "solar-panel-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "solar-panel-4"},
    max_health = 400,
    corpse = "big-remnants",
    collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__bobpower__/graphics/solar-panel/solar-panel-2.png",
      priority = "high",
      width = 104,
      height = 97
    },
    production = "3840kW",
    fast_replaceable_group = "solar-panel",
  },
  {
    type = "solar-panel",
    name = "solar-panel-large-4",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "solar-panel-large-4"},
    max_health = 600,
    corpse = "big-remnants",
    collision_box = {{-1.9, -1.9}, {1.9, 1.9}},
    selection_box = {{-2.0, -2.0}, {2.0, 2.0}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__bobpower__/graphics/solar-panel/solar-panel-l2.png",
      priority = "high",
      width = 136,
      height = 126
    },
    production = "6827.52kW",
    fast_replaceable_group = "solar-panel",
  }
})
-- data.raw["accumulator"]["large-accumulator-3"].next_upgrade = "large-accumulator-4"
-- data.raw["accumulator"]["fast-accumulator-3"].next_upgrade = "fast-accumulator-4"
-- data.raw["accumulator"]["slow-accumulator-3"].next_upgrade = "slow-accumulator-4"

-- data.raw["solar-panel"]["solar-panel-small-3"].next_upgrade = "solar-panel-small-4"
-- data.raw["solar-panel"]["solar-panel-3"].next_upgrade = "solar-panel-4"
-- data.raw["solar-panel"]["solar-panel-large-3"].next_upgrade = "solar-panel-large-4"