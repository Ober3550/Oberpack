--Misc Changes and Fixes
data.raw.recipe["red-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.recipe["green-wire"].ingredients = {{"electronic-circuit", 1}}
data.raw.item["beacon"].stack_size = 100

if mods["aai-industry"] then
    if not util then
    util = {}    
    end
    function util.allow_productivity(recipe_name)
        for _, prototype in pairs(data.raw["module"]) do
            if  prototype.limitation and string.find(prototype.name, "productivity", 1, true) then
                table.insert(prototype.limitation, recipe_name)
            end
        end
    end
    util.allow_productivity("motor")
    util.allow_productivity("electric-motor")
    data.raw.item["vehicle-fuel"].stack_size = 50
    data.raw.recipe["flying-robot-frame"].normal.ingredients = 
    {
          {"electric-engine-unit", 2},
          {"battery", 2},
          {"electronic-circuit", 2},
          {"steel-plate", 4},
    }
end
if mods.OmegaDrill then
--Omega Drill
data.raw.technology["omega-drill"].prerequisites = {"logistics-4", "bob-drills-4"}
data.raw.technology["omega-drill"].unit = {
    count = 300,
    ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1}
    },
    time = 30
}
data.raw["mining-drill"]["omega-drill"].module_specification = 
{
      module_slots = 10,
      module_info_icon_shift = {0, 0.5},
      module_info_multi_row_initial_height_modifier = -0.3
}
data.raw.recipe["omega-drill"].ingredients = 
{
    {"electric-engine-unit",25},
    {"turbo-transport-belt",10},
    {"bob-mining-drill-4",25},
    {"advanced-processing-unit",25},
    {"tungsten-gear-wheel",20},
    {"nitinol-bearing",10}

}
end
data.raw.item["nuclear-fuel"].stack_size = 2

if mods.bobplates then
--Fix the darn items left in inv from crafting bearings
local bearingBalls = {
    "steel-bearing-ball",
	"cobalt-steel-bearing-ball",
	"titanium-bearing-ball",
	"nitinol-bearing-ball",
	"ceramic-bearing-ball"
}
for key,value in pairs(bearingBalls) do
	data.raw.recipe[value].normal.result_count = 8
end

bobmods.lib.recipe.remove_ingredient("rocket-silo","processing-unit")
bobmods.lib.recipe.add_ingredient("rocket-silo",{"advanced-processing-unit",400})
bobmods.lib.recipe.remove_ingredient("rocket-silo","concrete")
bobmods.lib.recipe.add_ingredient("rocket-silo",{"refined-concrete",1000})

data.raw.technology["nitinol-processing"].unit.ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"advanced-logistic-science-pack", 1}
}
end

data.raw.recipe["belt-immunity-equipment"].ingredients = {
    {"turbo-transport-belt",20},
    {"exoskeleton-equipment",2}
}
bobmods.lib.tech.add_recipe_unlock("logistics-3", "belt-immunity-equipment")
data.raw["belt-immunity-equipment"]["belt-immunity-equipment"].shape = {width=2,height=2,type="full"}
data.raw.technology["belt-immunity-equipment"].hidden = true
data.raw.technology.plastics.unit.count = 50

if mods.boblogistics then
bobmods.lib.recipe.replace_ingredient("bob-pump-2","bronze-pipe","copper-pipe")
bobmods.lib.recipe.replace_ingredient("bob-pump-3","brass-pipe","bronze-pipe")
bobmods.lib.recipe.replace_ingredient("bob-pump-4","copper-tungsten-pipe","brass-pipe")

bobmods.lib.recipe.replace_ingredient("express-transport-belt","iron-gear-wheel","titanium-gear-wheel")
bobmods.lib.recipe.add_ingredient("express-transport-belt",{"titanium-bearing",5})
bobmods.lib.recipe.remove_ingredient("express-transport-belt","lubricant")

bobmods.lib.recipe.replace_ingredient("express-underground-belt","iron-gear-wheel","titanium-gear-wheel")
bobmods.lib.recipe.add_ingredient("express-underground-belt",{"titanium-bearing",20})
bobmods.lib.recipe.remove_ingredient("express-underground-belt","lubricant")

bobmods.lib.recipe.replace_ingredient("express-splitter","iron-gear-wheel","titanium-gear-wheel")
bobmods.lib.recipe.add_ingredient("express-splitter",{"titanium-bearing",5})
bobmods.lib.recipe.remove_ingredient("express-splitter","lubricant")

bobmods.lib.recipe.replace_ingredient("turbo-transport-belt","titanium-gear-wheel","nitinol-gear-wheel")
bobmods.lib.recipe.replace_ingredient("turbo-transport-belt","titanium-bearing","nitinol-bearing")

bobmods.lib.recipe.replace_ingredient("turbo-underground-belt","titanium-gear-wheel","nitinol-gear-wheel")
bobmods.lib.recipe.replace_ingredient("turbo-underground-belt","titanium-bearing","nitinol-bearing")

bobmods.lib.recipe.replace_ingredient("turbo-splitter","titanium-gear-wheel","nitinol-gear-wheel")
bobmods.lib.recipe.replace_ingredient("turbo-splitter","titanium-bearing","nitinol-bearing")
end