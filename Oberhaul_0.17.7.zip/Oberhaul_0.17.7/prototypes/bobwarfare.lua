if mods.bobwarfare and mods.bobequipment then
local removeTechnologies = {
	"bob-ap-bullets",
	"bob-electric-bullets",
	"bob-he-bullets",
	"bob-flame-bullets",
	"bob-acid-bullets",
	"bob-poison-bullets",
	"bob-shotgun-ap-shells",
	"bob-shotgun-electric-shells",
	"bob-shotgun-flame-shells",
	"bob-shotgun-acid-shells",
	"bob-shotgun-poison-shells",
	"bob-shotgun-explosive-shells",
	"bob-rocket",
	"bob-acid-rocket",
	"bob-flame-rocket",
	"bob-poison-rocket",
	"bob-electric-rocket",
	"bob-explosive-rocket",
	"bob-piercing-rocket",
	"bob-plasma-bullets",
	"bob-shotgun-plasma-shells",
	"bob-plasma-rocket"	
}

for key,value in pairs(removeTechnologies) do
	data.raw.technology[value].enabled = false
end

local removeRecipes = {
	"bullet-casing",
	"magazine",
	"bullet-projectile",
	"bullet",
	"uranium-bullet-projectile",
	"uranium-bullet",
	"shotgun-shell-casing",
	"rocket-engine"
}
--data.raw.technology["bob-shotgun-shells"].enabled = false
--data.raw.technology["bob-piercing-rocket"].enabled = false
--data.raw.recipe["shot"].hidden = true

--Lowering Complexity Increasing Requirement
for key,value in pairs(removeRecipes) do
	data.raw.recipe[value].hidden = true
end

data.raw.recipe["bullet-magazine"].ingredients = {
    {"piercing-rounds-magazine",1},
    {"steel-plate",3},
    {"lead-plate",5},
    {"gunmetal-alloy",2},
    {"cordite",3}
}
data.raw.recipe["uranium-rounds-magazine"].ingredients = {
    {"bullet-magazine",1},
    {"uranium-238",2},
    {"cordite",3},
    {"titanium-bearing-ball",4}
}
data.raw.recipe["better-shotgun-shell"].ingredients = {
    {"piercing-shotgun-shell",1},
    {"steel-plate",3},
    {"lead-plate",5},
    {"gunmetal-alloy",2},
    {"cordite",3}
}
data.raw.recipe["shotgun-uranium-shell"].ingredients = {
    {"better-shotgun-shell",1},
    {"uranium-238",2},
    {"cordite",3},
    {"titanium-bearing-ball",4}
}
data.raw.technology["bob-bullets"].effects = {{type = "unlock-recipe", recipe = "bullet-magazine"}}
data.raw.technology["bob-shotgun-shells"].effects = {
      {
        type = "unlock-recipe",
        recipe = "shot"
      },
      {
        type = "unlock-recipe",
        recipe = "better-shotgun-shell"
      }}
data.raw.technology["uranium-ammo"].effects = {
      {
	type = "unlock-recipe",
	recipe = "uranium-rounds-magazine"
      },
      {
	type = "unlock-recipe",
	recipe = "shotgun-uranium-shell"
      }
}
data.raw.technology["uranium-ammo"].unit = 
{
    count = 200,
    ingredients = {
    {"automation-science-pack", 1},
    {"logistic-science-pack", 1},
    {"chemical-science-pack", 1},
    {"military-science-pack",1}
    },
    time = 30
}

--Bobs Power Armor Rebalancing

bobmods.lib.recipe.remove_ingredient("power-armor-mk2","low-density-structure")
bobmods.lib.recipe.add_ingredient("bob-power-armor-mk4",{"heavy-armor-2",1})
bobmods.lib.recipe.add_ingredient("bob-power-armor-mk5",{"heavy-armor-3",1})
data.raw.technology["military-4"].unit.ingredients = {{"automation-science-pack",1},{"logistic-science-pack",1},{"chemical-science-pack",1},{"military-science-pack",1}}
data.raw.technology["military-4"].prerequisites = {"explosives","military-3"}

local technologyTiers = {}
technologyTiers[2] = {
	{"automation-science-pack", 1},
	{"logistic-science-pack", 1},
	{"chemical-science-pack", 1},
	{"military-science-pack", 1},
}
technologyTiers[3] = {
	{"automation-science-pack", 1},
	{"logistic-science-pack", 1},
	{"chemical-science-pack", 1},
	{"military-science-pack", 1},
	{"advanced-logistic-science-pack", 1}
}
technologyTiers[4] = {
	{"automation-science-pack", 1},
	{"logistic-science-pack", 1},
	{"chemical-science-pack", 1},
	{"military-science-pack", 1},
	{"advanced-logistic-science-pack", 1},
	{"production-science-pack", 1}
}
technologyTiers[5] = {
	{"automation-science-pack", 1},
	{"logistic-science-pack", 1},
	{"chemical-science-pack", 1},
	{"military-science-pack", 1},
	{"advanced-logistic-science-pack", 1},
	{"production-science-pack", 1},
	{"utility-science-pack",1}
}

local technologyRebalance = {}
technologyRebalance["power-armor-mk2"] = 2
technologyRebalance["bob-power-armor-3"] = 3
technologyRebalance["bob-power-armor-4"] = 4
technologyRebalance["bob-power-armor-5"] = 5
technologyRebalance["bob-battery-equipment-4"] = 3
technologyRebalance["personal-laser-defense-equipment-4"] = 3
technologyRebalance["personal-laser-defense-equipment-5"] = 4
technologyRebalance["bob-energy-shield-equipment-5"] = 4
technologyRebalance["bob-energy-shield-equipment-4"] = 3

for key,value in pairs(technologyRebalance) do
	data.raw.technology[key].unit.ingredients = technologyTiers[value]
end
end