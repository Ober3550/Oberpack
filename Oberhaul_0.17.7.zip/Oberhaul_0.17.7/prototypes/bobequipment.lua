if mods.bobequipment then
data.raw.recipe["solar-panel-equipment-4"].ingredients = {
      {"solar-panel-equipment-3", 1},
      {"steel-plate", 2},
      {"advanced-processing-unit", 5},
      {"copper-cable", 5},
}
data:extend({
  {
    type = "recipe",
    name = "ober-portable-solar",
    enabled = "false",
    energy_required = 10,
    ingredients = 
    {{"solar-panel-equipment-4",16}},
    result = "fusion-reactor-equipment",   
  }
})
bobmods.lib.tech.add_recipe_unlock("fusion-reactor-equipment", "ober-portable-solar")
end