data.raw["fluid-wagon"]["fluid-wagon"].capacity = 75000
data.raw["fluid-wagon"]["fluid-wagon"].weight = 3000
for _, recipe in pairs(data.raw["recipe"]) do
	if recipe.name:find("fill") then
		recipe.energy_required = 1
		for _, ingredient in pairs(recipe.ingredients) do
			if ingredient.type == "fluid" then
				ingredient.amount = 250
			end
		end
	elseif recipe.name:find("empty") then
		recipe.energy_required = 1
		if recipe.results ~= nil then
			for _, result in pairs(recipe.results) do
				if result.type == "fluid" then
					result.amount = 250
				end
			end
		end
	end
end