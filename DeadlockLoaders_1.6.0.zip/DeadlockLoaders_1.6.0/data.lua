-- global data
DCL = require("prototypes.shared")

-- main set-up
require("prototypes.items")
require("prototypes.recipes")
require("prototypes.entities")
require("prototypes.technology")
require("prototypes.styles")
require("prototypes.public")
