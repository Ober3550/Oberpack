local packs = {
    'automation-science-pack',
    'logistic-science-pack',
    'military-science-pack',
    'chemical-science-pack',
    'production-science-pack',
    'utility-science-pack',
    'space-science-pack'
}
if mods.boblogistics then
    table.insert(packs,'advanced-logistic-science-pack')
end

for _,n in pairs(packs) do
    local science = data.raw['tool'][n]
    science.icon = '__BetterFlasks__/graphics/icons/' .. n .. '.png'
    science.icon_size = 64
    science.icon_mipmaps = 4
end